# Flore du Burkina (squelette Flutter)

## Démarrage
1. `flutter create . --project-name flore_bf --platforms android`
   (génère le dossier android/ sans écraser lib/ ni pubspec.yaml)
2. Dans `android/app/build.gradle` : `minSdkVersion 21` (ou `minSdk = 21`).
3. Remplacez `assets/models/plants.tflite` par votre modèle entraîné.
4. `flutter pub get && flutter run`

## Brancher votre modèle
- `assets/models/labels.txt` : un id d'espèce par ligne, dans l'ordre exact des classes du modèle.
- Chaque id doit exister dans `assets/data/species.json`.
- Dans `lib/services/classifier.dart`, ajustez `_inputSize` et `_normalize01`
  selon votre entraînement.

## Ajouter une espèce
Ajoutez-la dans `species.json` et `labels.txt`, puis ré-entraînez le modèle.

## À faire
- Fiches : valider les noms locaux avec un botaniste et des locuteurs (`validated`).
- Photos de référence dans les fiches (assets/images/).
- Historique des observations (table `observations` déjà créée).
- Synchronisation en ligne des nouvelles espèces et observations.
