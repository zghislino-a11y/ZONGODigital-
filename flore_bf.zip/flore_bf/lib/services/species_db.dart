import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import '../models/species.dart';

/// Base SQLite locale : fiches des espèces + observations de l'utilisateur.
class SpeciesDb {
  static final SpeciesDb instance = SpeciesDb._();
  SpeciesDb._();

  late Database _db;

  Future<void> init() async {
    final path = p.join(await getDatabasesPath(), 'flore_bf.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, _) async {
      await db.execute(
          'CREATE TABLE species(id TEXT PRIMARY KEY, name TEXT, data TEXT)');
      await db.execute('''CREATE TABLE observations(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          species_id TEXT, confidence REAL,
          image_path TEXT, created_at TEXT)''');
    });
    await _seedFromAssets();
  }

  /// Recharge les fiches depuis le JSON embarqué (mise à jour à chaque version).
  Future<void> _seedFromAssets() async {
    final raw = await rootBundle.loadString('assets/data/species.json');
    final list = (jsonDecode(raw) as List)
        .map((e) => Species.fromJson(e as Map<String, dynamic>));
    final batch = _db.batch();
    for (final s in list) {
      batch.insert(
        'species',
        {'id': s.id, 'name': s.frenchName, 'data': s.encode()},
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }
    await batch.commit(noResult: true);
  }

  Future<Species?> getById(String id) async {
    final r = await _db.query('species', where: 'id = ?', whereArgs: [id]);
    return r.isEmpty ? null : Species.decode(r.first['data'] as String);
  }

  Future<List<Species>> all() async {
    final r = await _db.query('species', orderBy: 'name');
    return r.map((e) => Species.decode(e['data'] as String)).toList();
  }

  Future<void> saveObservation(
      String speciesId, double confidence, String imagePath) async {
    await _db.insert('observations', {
      'species_id': speciesId,
      'confidence': confidence,
      'image_path': imagePath,
      'created_at': DateTime.now().toIso8601String(),
    });
  }
}
