import 'dart:io';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';

class Prediction {
  final String speciesId;
  final double confidence; // 0.0 à 1.0
  const Prediction(this.speciesId, this.confidence);
}

/// Exécute le modèle TFLite embarqué (100 % hors ligne).
class Classifier {
  static const _modelPath = 'assets/models/plants.tflite';
  static const _labelsPath = 'assets/models/labels.txt';
  static const _inputSize = 224;

  // À adapter à l'entraînement : true => pixels en [0,1], false => [0,255]
  static const _normalize01 = false;

  Interpreter? _interpreter;
  List<String> _labels = [];

  bool get isReady => _interpreter != null;

  Future<void> load() async {
    final raw = await rootBundle.loadString(_labelsPath);
    _labels =
        raw.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    try {
      _interpreter = await Interpreter.fromAsset(_modelPath);
    } catch (_) {
      _interpreter = null; // modèle absent : l'app affichera un message
    }
  }

  Future<List<Prediction>> predict(File file, {int topK = 3}) async {
    final interpreter = _interpreter;
    if (interpreter == null) {
      throw StateError('Modèle non chargé. Ajoutez assets/models/plants.tflite');
    }

    var image = img.decodeImage(await file.readAsBytes())!;
    image = img.bakeOrientation(image);
    image = img.copyResize(image, width: _inputSize, height: _inputSize);

    final scale = _normalize01 ? 255.0 : 1.0;
    final input = [
      List.generate(
        _inputSize,
        (y) => List.generate(_inputSize, (x) {
          final px = image.getPixel(x, y);
          return [px.r / scale, px.g / scale, px.b / scale];
        }),
      )
    ];

    final output = [List<double>.filled(_labels.length, 0)];
    interpreter.run(input, output);

    final scores = output.first;
    final idx = List.generate(scores.length, (i) => i)
      ..sort((a, b) => scores[b].compareTo(scores[a]));

    return idx
        .take(topK)
        .map((i) => Prediction(_labels[i], scores[i]))
        .toList();
  }

  void dispose() => _interpreter?.close();
}
