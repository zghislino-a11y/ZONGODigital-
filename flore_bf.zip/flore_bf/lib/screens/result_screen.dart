import 'dart:io';
import 'package:flutter/material.dart';
import '../models/species.dart';
import '../services/classifier.dart';
import '../services/species_db.dart';
import 'species_detail_screen.dart';

class ResultScreen extends StatelessWidget {
  final File image;
  final List<Prediction> predictions;

  const ResultScreen(
      {super.key, required this.image, required this.predictions});

  static const _lowConfidence = 0.6;

  @override
  Widget build(BuildContext context) {
    final best = predictions.first;
    final uncertain = best.confidence < _lowConfidence;

    return Scaffold(
      appBar: AppBar(title: const Text('Résultat')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.file(image, height: 240, fit: BoxFit.cover),
          ),
          const SizedBox(height: 16),
          if (uncertain)
            Card(
              color: Colors.orange.shade100,
              child: const Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                    'Confiance faible : essayez une autre photo (bonne lumière, '
                    'feuille ou fruit bien cadré). Résultat à ne pas utiliser '
                    'pour la consommation.'),
              ),
            ),
          const SizedBox(height: 8),
          for (final p in predictions) _PredictionTile(prediction: p),
          const SizedBox(height: 16),
          FilledButton.tonalIcon(
            icon: const Icon(Icons.bookmark_add),
            label: const Text('Enregistrer cette observation'),
            onPressed: () async {
              await SpeciesDb.instance
                  .saveObservation(best.speciesId, best.confidence, image.path);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Observation enregistrée')));
              }
            },
          ),
        ],
      ),
    );
  }
}

class _PredictionTile extends StatelessWidget {
  final Prediction prediction;
  const _PredictionTile({required this.prediction});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Species?>(
      future: SpeciesDb.instance.getById(prediction.speciesId),
      builder: (context, snap) {
        final s = snap.data;
        final pct = (prediction.confidence * 100).toStringAsFixed(0);
        return Card(
          child: ListTile(
            title: Text(s?.frenchName ?? prediction.speciesId),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (s != null)
                  Text(s.scientificName,
                      style: const TextStyle(fontStyle: FontStyle.italic)),
                const SizedBox(height: 6),
                LinearProgressIndicator(value: prediction.confidence),
              ],
            ),
            trailing: Text('$pct %',
                style: const TextStyle(fontWeight: FontWeight.bold)),
            onTap: s == null
                ? null
                : () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => SpeciesDetailScreen(species: s))),
          ),
        );
      },
    );
  }
}
