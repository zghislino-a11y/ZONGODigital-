import 'package:flutter/material.dart';
import '../models/species.dart';
import '../services/species_db.dart';
import 'species_detail_screen.dart';

class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bibliothèque')),
      body: FutureBuilder<List<Species>>(
        future: SpeciesDb.instance.all(),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final list = snap.data!;
          return ListView.separated(
            itemCount: list.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (_, i) => ListTile(
              title: Text(list[i].frenchName),
              subtitle: Text(list[i].scientificName),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) =>
                          SpeciesDetailScreen(species: list[i]))),
            ),
          );
        },
      ),
    );
  }
}
