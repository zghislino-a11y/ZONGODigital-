import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../main.dart';
import 'library_screen.dart';
import 'result_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _picker = ImagePicker();
  bool _busy = false;

  Future<void> _scan(ImageSource source) async {
    final shot = await _picker.pickImage(source: source, maxWidth: 1024);
    if (shot == null) return;
    setState(() => _busy = true);
    try {
      final file = File(shot.path);
      final predictions = await classifier.predict(file);
      if (!mounted) return;
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) =>
                ResultScreen(image: file, predictions: predictions)),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Erreur : $e')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flore du Burkina'),
        actions: [
          IconButton(
            icon: const Icon(Icons.menu_book),
            tooltip: 'Bibliothèque',
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const LibraryScreen())),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.eco, size: 96, color: Colors.green),
            const SizedBox(height: 16),
            Text('Photographiez une feuille ou un fruit',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 32),
            if (_busy)
              const Center(child: CircularProgressIndicator())
            else ...[
              FilledButton.icon(
                onPressed: () => _scan(ImageSource.camera),
                icon: const Icon(Icons.camera_alt),
                label: const Text('Scanner'),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () => _scan(ImageSource.gallery),
                icon: const Icon(Icons.photo_library),
                label: const Text('Choisir une photo'),
              ),
            ],
            const SizedBox(height: 32),
            const Text(
              'Ne consommez jamais une plante sur la seule base de cette application.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
