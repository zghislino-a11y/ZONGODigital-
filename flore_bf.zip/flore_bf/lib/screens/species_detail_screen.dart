import 'package:flutter/material.dart';
import '../models/species.dart';

class SpeciesDetailScreen extends StatelessWidget {
  final Species species;
  const SpeciesDetailScreen({super.key, required this.species});

  static const _langLabels = {
    'moore': 'Mooré',
    'dioula': 'Dioula',
    'fulfulde': 'Fulfuldé',
    'gulmancema': 'Gulmancema',
  };

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: Text(species.frenchName)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(species.scientificName,
              style: t.titleLarge?.copyWith(fontStyle: FontStyle.italic)),
          Text('Famille : ${species.family}'),
          if (!species.validated)
            const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Chip(label: Text('Fiche en attente de validation')),
              ),
            ),
          const SizedBox(height: 16),
          _Section(
              'Noms locaux',
              [
                for (final e in species.localNames.entries)
                  '${_langLabels[e.key] ?? e.key} : ${e.value}'
              ].join('\n')),
          _Section('Description', species.description),
          _Section('Usages', species.uses),
          _Section('Toxicité / précautions', species.toxicity),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title, body;
  const _Section(this.title, this.body);

  @override
  Widget build(BuildContext context) {
    if (body.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          Text(body),
        ],
      ),
    );
  }
}
