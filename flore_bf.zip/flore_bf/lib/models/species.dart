import 'dart:convert';

class Species {
  final String id;
  final String scientificName;
  final String frenchName;
  final Map<String, String> localNames;
  final String family;
  final String description;
  final String uses;
  final String toxicity;
  final bool validated;

  const Species({
    required this.id,
    required this.scientificName,
    required this.frenchName,
    required this.localNames,
    required this.family,
    required this.description,
    required this.uses,
    required this.toxicity,
    required this.validated,
  });

  factory Species.fromJson(Map<String, dynamic> j) => Species(
        id: j['id'] as String,
        scientificName: j['scientific_name'] as String,
        frenchName: j['french_name'] as String,
        localNames: Map<String, String>.from(j['local_names'] ?? {}),
        family: j['family'] ?? '',
        description: j['description'] ?? '',
        uses: j['uses'] ?? '',
        toxicity: j['toxicity'] ?? '',
        validated: j['validated'] ?? false,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'scientific_name': scientificName,
        'french_name': frenchName,
        'local_names': localNames,
        'family': family,
        'description': description,
        'uses': uses,
        'toxicity': toxicity,
        'validated': validated,
      };

  String encode() => jsonEncode(toJson());
  factory Species.decode(String s) => Species.fromJson(jsonDecode(s));
}
