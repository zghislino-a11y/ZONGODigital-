import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'services/classifier.dart';
import 'services/species_db.dart';

final classifier = Classifier();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SpeciesDb.instance.init();
  await classifier.load();
  runApp(const FloreBfApp());
}

class FloreBfApp extends StatelessWidget {
  const FloreBfApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flore du Burkina',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF2E7D32),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}
