# MyVpn — application VPN Android (SSH + V2Ray)

## Fonctionnement
- Le cœur **Xray** (libv2ray) lit les paquets de l'interface VPN (TUN).
- Profil **V2Ray** : Xray envoie le trafic vers ton serveur (liens vmess://, vless://, trojan:// ou JSON).
- Profil **SSH** : l'app ouvre un tunnel SSH avec un SOCKS local (`SshEngine`), et Xray y envoie le trafic.

## Fabrication
`libv2ray.aar` est fabriqué automatiquement par `ci/build-aar.sh` (lancé par Gradle) à partir de
https://github.com/2dust/AndroidLibXrayLite. Le premier build est plus long (compilation de Xray).

## Points d'attention
- Version non testée sur téléphone : un premier échec de connexion est possible, le message d'erreur s'affiche dans l'app.
- Sécurité SSH : l'empreinte de la clé du serveur n'est pas vérifiée si le champ est vide ; mots de passe stockés en clair.
- SSH ne transporte pas l'UDP : le DNS passe en TCP via le tunnel.
- À ajouter ensuite : notification de service, reconnexion automatique, import par QR code.
