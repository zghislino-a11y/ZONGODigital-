#!/usr/bin/env bash
# Fabrique libv2ray.aar (moteur Xray) à partir des sources de 2dust/AndroidLibXrayLite.
# Lancé automatiquement par Gradle (tâche buildLibV2ray) si app/libs/libv2ray.aar est absent.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/app/libs"
TMP="$(mktemp -d)"

git clone --depth 1 https://github.com/2dust/AndroidLibXrayLite "$TMP/lib"

export PATH="$PATH:$(go env GOPATH)/bin"
export ANDROID_HOME="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
export ANDROID_NDK_HOME="${ANDROID_NDK_HOME:-${ANDROID_NDK_LATEST_HOME:-}}"

go install golang.org/x/mobile/cmd/gomobile@latest
go install golang.org/x/mobile/cmd/gobind@latest
gomobile init

cd "$TMP/lib"
go mod tidy -v
go get golang.org/x/mobile/bind || true
gomobile bind -v -androidapi 24 -target=android/arm64,android/arm -trimpath \
  -ldflags='-s -w -buildid= -checklinkname=0' \
  -o libv2ray.aar ./

cp libv2ray.aar "$ROOT/app/libs/libv2ray.aar"
echo "libv2ray.aar prêt"
