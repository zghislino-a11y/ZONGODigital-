plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.myvpn"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.myvpn"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "1.2"
        // Téléphones récents (64 bits) et anciens (32 bits) seulement : APK bien plus léger
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    // Clé fixe : les mises à jour s'installent par-dessus la version précédente
    signingConfigs {
        getByName("debug") {
            storeFile = file("zongo-debug.jks")
            storePassword = "android"
            keyAlias = "zongo"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging {
        resources.excludes += setOf("META-INF/versions/9/OSGI-INF/MANIFEST.MF", "META-INF/*.kotlin_module")
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(composeBom)
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // SSH (client) + journalisation compatible Android
    implementation("com.hierynomus:sshj:0.38.0")
    implementation("org.slf4j:slf4j-android:1.7.36")

    // Moteur Xray/V2Ray (fabriqué par ci/build-aar.sh)
    implementation(files("libs/libv2ray.aar"))
}

// Fabrique libv2ray.aar avant la compilation s'il n'existe pas encore
tasks.register<Exec>("buildLibV2ray") {
    val aar = layout.projectDirectory.file("libs/libv2ray.aar").asFile
    onlyIf { !aar.exists() }
    workingDir = rootProject.projectDir
    commandLine("bash", "ci/build-aar.sh")
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn("buildLibV2ray") }
