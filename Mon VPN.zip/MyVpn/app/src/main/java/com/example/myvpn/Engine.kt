package com.example.myvpn

import android.content.Context
import android.system.Os
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray

/** Un "moteur" expose un proxy SOCKS5 local (127.0.0.1:socksPort) vers le serveur. */
interface Engine {
    fun start(profile: Profile, socksPort: Int)
    fun stop()
}

/** État partagé service -> interface. */
object VpnState {
    val connected = MutableStateFlow<String?>(null) // id du profil connecté
    val error = MutableStateFlow<String?>(null)
    val connecting = MutableStateFlow(false)
}

/** Petit journal écrit dans un fichier, affiché par le bouton « Journal » de l'application. */
object AppLog {
    private var file: File? = null

    fun init(context: Context) {
        if (file == null) file = File(context.filesDir, "app.log")
    }

    fun path(): String? = file?.absolutePath

    fun reset() {
        try { file?.writeText("") } catch (_: Throwable) {}
    }

    fun add(msg: String) {
        try {
            val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
            file?.appendText("$t  $msg\n")
        } catch (_: Throwable) {}
    }

    fun tail(max: Int = 8000): String =
        try { file?.readText()?.takeLast(max) ?: "" } catch (_: Throwable) { "" }
}

/**
 * Cœur Xray (libv2ray). Il lit directement les paquets de l'interface TUN :
 *  - profil V2Ray : il envoie le trafic vers ton serveur V2Ray ;
 *  - profil SSH   : il envoie le trafic vers le SOCKS local du tunnel SSH.
 */
object XrayCore {
    private var controller: CoreController? = null

    fun start(context: Context, configJson: String, tunFd: Int) {
        stop()
        // Certaines versions lisent le descripteur TUN depuis cette variable d'environnement
        Os.setenv("XRAY_TUN_FD", tunFd.toString(), true)
        Libv2ray.initCoreEnv(context.filesDir.absolutePath, "")
        val c = Libv2ray.newCoreController(object : CoreCallbackHandler {
            override fun startup(): Long = 0
            override fun shutdown(): Long = 0
            override fun onEmitStatus(code: Long, message: String?): Long {
                AppLog.add("Xray : $message")
                return 0
            }
        })
        c.startLoop(configJson, tunFd)
        controller = c
    }

    fun stop() {
        try { controller?.stopLoop() } catch (_: Throwable) {}
        controller = null
    }
}
