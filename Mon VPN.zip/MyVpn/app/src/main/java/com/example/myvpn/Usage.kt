package com.example.myvpn

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Données consommées par le VPN sur ce téléphone : aujourd'hui, ce mois-ci et au total. */
object Usage {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("usage", Context.MODE_PRIVATE)
    private fun day() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
    private fun month() = SimpleDateFormat("yyyyMM", Locale.US).format(Date())

    @Synchronized
    fun add(ctx: Context, rx: Long, tx: Long) {
        val n = rx + tx
        if (n <= 0) return
        val p = prefs(ctx)
        val dk = "d_" + day(); val mk = "m_" + month()
        p.edit()
            .putLong(dk, p.getLong(dk, 0) + n)
            .putLong(mk, p.getLong(mk, 0) + n)
            .putLong("total", p.getLong("total", 0) + n)
            .apply()
    }

    /** (aujourd'hui, ce mois, total) en octets */
    fun summary(ctx: Context): Triple<Long, Long, Long> {
        val p = prefs(ctx)
        return Triple(p.getLong("d_" + day(), 0), p.getLong("m_" + month(), 0), p.getLong("total", 0))
    }
}
