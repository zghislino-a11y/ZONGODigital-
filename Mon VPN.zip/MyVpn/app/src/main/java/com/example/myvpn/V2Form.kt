package com.example.myvpn

import android.net.Uri
import android.util.Base64
import org.json.JSONObject

/** Les réglages V2Ray sous forme de champs séparés (le profil garde un lien comme source). */
data class V2Form(
    val protocol: String = "vmess",
    val name: String = "",
    val address: String = "",
    val port: String = "443",
    val id: String = "",
    val alterId: String = "0",
    val security: String = "auto",
    val network: String = "tcp",
    val headerType: String = "none",
    val host: String = "",
    val path: String = "",
    val tls: String = "tls",
    val sni: String = "",
    val fp: String = "",
    val alpn: String = "",
    val insecure: Boolean = false,
    val flow: String = "",
    val pbk: String = "",
    val sid: String = "",
    val spx: String = "",
) {
    fun toLink(): String = when (protocol) {
        "vless" -> vlessLink()
        "trojan" -> trojanLink()
        else -> vmessLink()
    }

    private fun trojanLink(): String {
        val params = linkedMapOf(
            "security" to tls, "sni" to sni, "fp" to fp, "alpn" to alpn,
            "type" to network, "headerType" to headerType, "host" to host,
            (if (network == "grpc") "serviceName" else "path") to path,
            "pbk" to pbk, "sid" to sid, "spx" to spx,
            "allowInsecure" to (if (insecure) "1" else "")
        )
        val q = params.filter { it.value.isNotBlank() }.entries
            .joinToString("&") { "${it.key}=${Uri.encode(it.value)}" }
        return "trojan://${Uri.encode(id)}@$address:$port?$q#${Uri.encode(name)}"
    }

    private fun vmessLink(): String {
        val j = JSONObject()
            .put("v", "2").put("ps", name).put("add", address).put("port", port)
            .put("id", id).put("aid", alterId).put("scy", security)
            .put("net", network).put("type", headerType).put("host", host).put("path", path)
            .put("tls", if (tls == "tls") "tls" else "").put("sni", sni)
            .put("alpn", alpn).put("fp", fp)
            .put("allowInsecure", if (insecure) "1" else "0")
        return "vmess://" + Base64.encodeToString(j.toString().toByteArray(), Base64.NO_WRAP)
    }

    private fun vlessLink(): String {
        val params = linkedMapOf(
            "encryption" to "none", "flow" to flow, "security" to tls, "sni" to sni,
            "fp" to fp, "alpn" to alpn, "type" to network, "headerType" to headerType,
            "host" to host, (if (network == "grpc") "serviceName" else "path") to path,
            "pbk" to pbk, "sid" to sid, "spx" to spx,
            "allowInsecure" to (if (insecure) "1" else "")
        )
        val q = params.filter { it.value.isNotBlank() }.entries
            .joinToString("&") { "${it.key}=${Uri.encode(it.value)}" }
        return "vless://${Uri.encode(id)}@$address:$port?$q#${Uri.encode(name)}"
    }

    companion object {
        fun fromLink(link: String): V2Form = try {
            val l = link.trim()
            when {
                l.startsWith("vmess://") -> parseVmess(l)
                l.startsWith("vless://") -> parseVless(l)
                l.startsWith("trojan://") -> parseTrojan(l)
                else -> V2Form()
            }
        } catch (_: Exception) {
            V2Form()
        }

        private fun parseVmess(l: String): V2Form {
            var b64 = l.removePrefix("vmess://").trim().replace('-', '+').replace('_', '/')
            while (b64.length % 4 != 0) b64 += "="
            val j = JSONObject(String(Base64.decode(b64, Base64.DEFAULT)))
            fun s(k: String) = j.optString(k)
            return V2Form(
                protocol = "vmess", name = s("ps"), address = s("add"),
                port = s("port").ifBlank { "443" }, id = s("id"),
                alterId = s("aid").ifBlank { "0" }, security = s("scy").ifBlank { "auto" },
                network = s("net").ifBlank { "tcp" }, headerType = s("type").ifBlank { "none" },
                host = s("host"), path = s("path"),
                tls = if (s("tls") == "tls") "tls" else "none",
                sni = s("sni"), fp = s("fp"), alpn = s("alpn"),
                insecure = s("allowInsecure") == "1" || s("allowInsecure") == "true"
            )
        }

        private fun parseTrojan(l: String): V2Form {
            val u = Uri.parse(l)
            fun q(k: String) = u.getQueryParameter(k) ?: ""
            return V2Form(
                protocol = "trojan", name = u.fragment ?: "", address = u.host ?: "",
                port = if (u.port > 0) u.port.toString() else "443", id = u.userInfo ?: "",
                network = q("type").ifBlank { "tcp" }, headerType = q("headerType").ifBlank { "none" },
                host = q("host"), path = q("path").ifBlank { q("serviceName") },
                tls = q("security").ifBlank { "tls" }, sni = q("sni"), fp = q("fp"), alpn = q("alpn"),
                insecure = q("allowInsecure") == "1" || q("insecure") == "1",
                pbk = q("pbk"), sid = q("sid"), spx = q("spx")
            )
        }

        private fun parseVless(l: String): V2Form {
            val u = Uri.parse(l)
            fun q(k: String) = u.getQueryParameter(k) ?: ""
            return V2Form(
                protocol = "vless", name = u.fragment ?: "", address = u.host ?: "",
                port = if (u.port > 0) u.port.toString() else "443", id = u.userInfo ?: "",
                network = q("type").ifBlank { "tcp" }, headerType = q("headerType").ifBlank { "none" },
                host = q("host"), path = q("path").ifBlank { q("serviceName") },
                tls = q("security").ifBlank { "none" }, sni = q("sni"), fp = q("fp"), alpn = q("alpn"),
                insecure = q("allowInsecure") == "1" || q("insecure") == "1",
                flow = q("flow"), pbk = q("pbk"), sid = q("sid"), spx = q("spx")
            )
        }
    }
}

/** Petit résumé affiché sous le nom du serveur. */
fun v2Summary(p: Profile): String {
    val f = V2Form.fromLink(p.link)
    return if (f.address.isBlank()) "Lien V2Ray" else "${f.address}:${f.port} · ${f.network}"
}
