package com.example.myvpn

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Fichiers ZONGO Digital : le contenu commence par « zongodigital:// » puis les serveurs
 * chiffrés (AES-256-GCM). Les serveurs importés sont « protégés » : on ne voit pas leurs détails.
 * NB : la clé est dans l'application, c'est une protection contre la lecture à l'œil nu,
 * pas une sécurité absolue.
 */
object ZongoCodec {
    const val PREFIX = "zongodigital://"
    const val EXTENSION = "zongo"
    private const val SECRET = "ZONGO-Digital-ZNG-22657544635-v1"

    private val key by lazy {
        SecretKeySpec(MessageDigest.getInstance("SHA-256").digest(SECRET.toByteArray()), "AES")
    }

    fun isZongo(text: String) = text.trim().startsWith(PREFIX)

    fun encode(plain: String): String {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        val out = iv + c.doFinal(plain.toByteArray(Charsets.UTF_8))
        return PREFIX + Base64.encodeToString(out, Base64.NO_WRAP or Base64.URL_SAFE)
    }

    fun decode(text: String): String? = try {
        val b64 = text.trim().removePrefix(PREFIX).filter { !it.isWhitespace() }
        val raw = Base64.decode(b64, Base64.URL_SAFE)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, raw.copyOfRange(0, 12)))
        String(c.doFinal(raw.copyOfRange(12, raw.size)), Charsets.UTF_8)
    } catch (_: Exception) {
        null
    }

    /** Serveurs -> texte « zongodigital://… » (les serveurs déjà protégés ne sont pas ré-exportés). */
    fun export(list: List<Profile>): String {
        val arr = JSONArray()
        list.filter { !it.locked }.forEach { arr.put(it.copy(locked = true).toJson()) }
        val json = JSONObject().put("app", "zongodigital").put("v", 1).put("servers", arr)
        return encode(json.toString())
    }

    /** Texte « zongodigital://… » -> serveurs protégés (nouveaux identifiants). */
    fun import(text: String): List<Profile> = try {
        if (!isZongo(text)) emptyList()
        else {
            val arr = JSONObject(decode(text) ?: "").getJSONArray("servers")
            (0 until arr.length()).map {
                Profile.fromJson(arr.getJSONObject(it)).copy(id = UUID.randomUUID().toString(), locked = true)
            }
        }
    } catch (_: Exception) {
        emptyList()
    }
}
