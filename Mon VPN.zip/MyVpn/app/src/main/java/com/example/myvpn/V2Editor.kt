package com.example.myvpn

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

private val EdBg = Color(0xFF040A18)
private val EdGreen = Color(0xFF2F8CFF)
private val EdGreenBg = Color(0xFF0B1630)
private val EdMuted = Color(0xFF8FA3C7)

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = EdGreen,
    unfocusedBorderColor = EdGreen.copy(alpha = 0.45f),
    focusedLabelColor = EdGreen,
    unfocusedLabelColor = EdMuted,
    cursorColor = EdGreen,
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedContainerColor = EdGreenBg,
    unfocusedContainerColor = EdGreenBg,
)

@Composable
private fun GField(
    label: String, value: String, onChange: (String) -> Unit,
    modifier: Modifier = Modifier.fillMaxWidth(), keyboard: KeyboardType = KeyboardType.Text
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        modifier = modifier, shape = RoundedCornerShape(16.dp), colors = fieldColors(),
        keyboardOptions = KeyboardOptions(keyboardType = keyboard)
    )
}

@Composable
private fun GDropdown(label: String, value: String, options: List<String>, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = value.ifBlank { "(aucun)" }, onValueChange = {}, readOnly = true,
            label = { Text(label) }, singleLine = true,
            trailingIcon = { Text("▾", color = EdGreen, fontSize = 18.sp) },
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = fieldColors()
        )
        Box(Modifier.matchParentSize().clickable { open = true })
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach {
                DropdownMenuItem(
                    text = { Text(it.ifBlank { "(aucun)" }) },
                    onClick = { onSelect(it); open = false }
                )
            }
        }
    }
}

@Composable
private fun Section(title: String) {
    Spacer(Modifier.height(6.dp))
    HorizontalDivider(color = EdGreen.copy(alpha = 0.25f))
    Text(title, color = EdGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
}

/** Formulaire plein écran pour créer ou modifier un serveur V2Ray (vmess / vless). */
@Composable
fun V2Editor(
    initial: Profile?, onDismiss: () -> Unit, onSave: (Profile) -> Unit,
    presetProtocol: String = "vmess"
) {
    var f by remember {
        mutableStateOf(
            if (initial != null) V2Form.fromLink(initial.link).let {
                if (it.name.isBlank()) it.copy(name = initial.name) else it
            } else V2Form(protocol = presetProtocol)
        )
    }
    var paste by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }

    fun save() {
        val port = f.port.toIntOrNull()
        when {
            f.address.isBlank() -> err = "Adresse manquante"
            port == null || port !in 1..65535 -> err = "Port invalide"
            f.id.isBlank() -> err = if (f.protocol == "trojan") "Mot de passe manquant" else "ID utilisateur manquant"
            else -> {
                val name = f.name.ifBlank { "V2Ray" }
                val p = Profile(name = name, type = ProfileType.V2RAY, link = f.copy(name = name).toLink())
                onSave(if (initial != null) p.copy(id = initial.id) else p)
            }
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = EdBg) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onDismiss) { Text("✕", color = Color.White, fontSize = 22.sp) }
                    Text(
                        if (initial == null) "Nouveau serveur ${presetProtocol.uppercase()}" else "Modifier ${f.protocol.uppercase()}",
                        color = Color.White, fontSize = 18.sp, modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { save() }) { Text("✓", color = EdGreen, fontSize = 26.sp) }
                }
                Column(
                    Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Import d'un lien
                    GField("Coller un lien vmess:// vless:// trojan://", paste, { paste = it })
                    Button(
                        onClick = {
                            val n = V2Form.fromLink(paste)
                            if (n.address.isBlank()) err = "Lien non reconnu"
                            else { f = n; err = null; paste = "" }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EdGreen, contentColor = Color.White),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("Importer le lien") }

                    err?.let { Text(it, color = Color(0xFFFF5C6C), fontSize = 13.sp) }

                    Section("SERVEUR")
                    GDropdown("Protocole", f.protocol, listOf("vmess", "vless", "trojan")) {
                        f = f.copy(protocol = it, tls = if (it == "trojan" && f.tls == "none") "tls" else f.tls)
                    }
                    GField("Remarques (nom)", f.name, { f = f.copy(name = it) })
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GField("Adresse", f.address, { f = f.copy(address = it) }, Modifier.weight(3f))
                        GField("Port", f.port, { f = f.copy(port = it) }, Modifier.weight(1.3f), KeyboardType.Number)
                    }

                    Section("IDENTIFIANTS")
                    GField(if (f.protocol == "trojan") "Mot de passe" else "ID utilisateur", f.id, { f = f.copy(id = it) })
                    if (f.protocol == "vmess") {
                        GField("Alter ID", f.alterId, { f = f.copy(alterId = it) }, keyboard = KeyboardType.Number)
                        GDropdown(
                            "Méthode de chiffrement", f.security,
                            listOf("auto", "aes-128-gcm", "chacha20-poly1305", "none", "zero")
                        ) { f = f.copy(security = it) }
                    } else if (f.protocol == "vless") {
                        GDropdown("Flow", f.flow, listOf("", "xtls-rprx-vision")) { f = f.copy(flow = it) }
                    }

                    Section("TRANSPORT")
                    GDropdown("Protocole de transfert", f.network, listOf("tcp", "ws", "grpc", "httpupgrade", "xhttp")) {
                        f = f.copy(network = it, headerType = if (it == "grpc") "gun" else "none")
                    }
                    val headers = when (f.network) {
                        "grpc" -> listOf("gun", "multi")
                        "tcp" -> listOf("none", "http")
                        else -> listOf("none")
                    }
                    GDropdown("Type d'en-tête", f.headerType, headers) { f = f.copy(headerType = it) }
                    GField(
                        if (f.network == "grpc") "Authority (hôte)" else "Hôte (host)",
                        f.host, { f = f.copy(host = it) }
                    )
                    GField(
                        if (f.network == "grpc") "Nom du service (service name)" else "Chemin (path)",
                        f.path, { f = f.copy(path = it) }
                    )

                    Section("SÉCURITÉ")
                    GDropdown("Type TLS", f.tls, listOf("none", "tls", "reality")) { f = f.copy(tls = it) }
                    if (f.tls != "none") {
                        GField("SNI", f.sni, { f = f.copy(sni = it) })
                        GDropdown(
                            "Empreinte (fingerprint)", f.fp,
                            listOf("", "chrome", "firefox", "safari", "ios", "android", "randomized")
                        ) { f = f.copy(fp = it) }
                        GField("ALPN", f.alpn, { f = f.copy(alpn = it) })
                        if (f.tls == "reality") {
                            GField("Clé publique (pbk)", f.pbk, { f = f.copy(pbk = it) })
                            GField("Short ID (sid)", f.sid, { f = f.copy(sid = it) })
                            GField("SpiderX (spx)", f.spx, { f = f.copy(spx = it) })
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Autoriser le certificat non sécurisé", color = Color.White,
                                fontSize = 14.sp, modifier = Modifier.weight(1f)
                            )
                            Switch(
                                checked = f.insecure, onCheckedChange = { f = f.copy(insecure = it) },
                                colors = SwitchDefaults.colors(checkedTrackColor = EdGreen, checkedThumbColor = Color.White)
                            )
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}
