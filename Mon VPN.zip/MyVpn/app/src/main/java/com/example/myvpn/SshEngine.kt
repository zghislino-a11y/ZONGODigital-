package com.example.myvpn

import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.transport.verification.PromiscuousVerifier
import java.io.DataInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

/**
 * Tunnel SSH "dynamique" : un mini serveur SOCKS5 local qui ouvre un canal
 * direct-tcpip SSH pour chaque connexion (équivalent de `ssh -D`).
 * sshj n'offre pas -D nativement, d'où cette implémentation.
 */
class SshEngine : Engine {
    private var ssh: SSHClient? = null
    private var server: ServerSocket? = null

    override fun start(profile: Profile, socksPort: Int) {
        val client = SSHClient()
        if (profile.hostKeyFingerprint.isBlank()) {
            client.addHostKeyVerifier(PromiscuousVerifier()) // TODO : épingler l'empreinte
        } else {
            client.addHostKeyVerifier(profile.hostKeyFingerprint)
        }
        client.connect(profile.host, profile.port)
        client.authPassword(profile.user, profile.password)
        client.connection.keepAlive.keepAliveInterval = 15
        ssh = client

        val ss = ServerSocket(socksPort, 50, InetAddress.getByName("127.0.0.1"))
        server = ss
        thread(name = "socks-accept", isDaemon = true) {
            while (!ss.isClosed) {
                val s = try { ss.accept() } catch (_: Exception) { break }
                thread(isDaemon = true) { handle(s) }
            }
        }
    }

    private fun handle(sock: Socket) {
        sock.use { s ->
            val input = DataInputStream(s.getInputStream())
            val out = s.getOutputStream()

            // Négociation SOCKS5 : aucune authentification
            if (input.readUnsignedByte() != 5) return
            input.skipBytes(input.readUnsignedByte())
            out.write(byteArrayOf(5, 0)); out.flush()

            // Requête
            input.readUnsignedByte() // version
            val cmd = input.readUnsignedByte()
            input.readUnsignedByte() // reserved
            val host = when (input.readUnsignedByte()) {
                1 -> ByteArray(4).also { input.readFully(it) }.let { InetAddress.getByAddress(it).hostAddress }
                3 -> ByteArray(input.readUnsignedByte()).also { input.readFully(it) }.toString(Charsets.UTF_8)
                4 -> ByteArray(16).also { input.readFully(it) }.let { InetAddress.getByAddress(it).hostAddress }
                else -> { reply(out, 8); return }
            }
            val port = input.readUnsignedShort()
            if (cmd != 1) { reply(out, 7); return } // seul CONNECT est géré

            val client = ssh ?: return
            val channel = try {
                client.newDirectConnection(host, port)
            } catch (_: Exception) { reply(out, 5); return }

            channel.use { ch ->
                reply(out, 0)
                val t = thread(isDaemon = true) { pipe(ch.inputStream, out) }
                pipe(input, ch.outputStream)
                t.join(1000)
            }
        }
    }

    private fun reply(out: OutputStream, code: Int) {
        out.write(byteArrayOf(5, code.toByte(), 0, 1, 0, 0, 0, 0, 0, 0)); out.flush()
    }

    private fun pipe(from: InputStream, to: OutputStream) {
        val buf = ByteArray(16 * 1024)
        try {
            while (true) {
                val n = from.read(buf)
                if (n < 0) break
                to.write(buf, 0, n); to.flush()
            }
        } catch (_: Exception) {
        }
    }

    override fun stop() {
        try { server?.close() } catch (_: Exception) {}
        try { ssh?.disconnect() } catch (_: Exception) {}
        server = null; ssh = null
    }
}
