package com.example.myvpn

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class UpdateInfo(
    val versionCode: Int,
    val versionName: String,
    val url: String,
    val notes: String,
    val force: Boolean
)

/**
 * Vérifie s'il existe une version plus récente. Le fichier version.json est à la racine du dépôt GitHub :
 * {"versionCode": 3, "versionName": "1.2", "url": "https://…", "notes": "Nouveautés…", "force": false}
 */
object UpdateChecker {
    const val VERSION_URL = "https://raw.githubusercontent.com/zghislino-a11y/ZONGODigital-/main/version.json"

    @Suppress("DEPRECATION")
    fun installedCode(ctx: Context): Int = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionCode
    } catch (_: Exception) { 0 }

    fun installedName(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    } catch (_: Exception) { "" }

    /** Retourne les infos de la nouvelle version, ou null s'il n'y en a pas (ou si pas de réseau). */
    suspend fun check(ctx: Context): UpdateInfo? = withContext(Dispatchers.IO) {
        try {
            val c = URL(VERSION_URL).openConnection() as HttpURLConnection
            c.connectTimeout = 5000; c.readTimeout = 5000
            val text = try {
                if (c.responseCode != 200) return@withContext null
                c.inputStream.bufferedReader().use { it.readText() }
            } finally { c.disconnect() }
            val o = JSONObject(text)
            val info = UpdateInfo(
                versionCode = o.getInt("versionCode"),
                versionName = o.optString("versionName"),
                url = o.getString("url"),
                notes = o.optString("notes"),
                force = o.optBoolean("force", false)
            )
            if (info.versionCode > installedCode(ctx) && info.url.startsWith("http")) info else null
        } catch (_: Exception) { null }
    }
}
