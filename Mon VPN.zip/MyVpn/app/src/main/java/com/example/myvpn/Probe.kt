package com.example.myvpn

import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLException
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509TrustManager

/** Petit proxy SOCKS local (protégé par mot de passe) servant uniquement à tester la connexion. */
object TestProxy {
    const val PORT = 10809
    const val USER = "zng"
    @Volatile var pass: String = "zng"

    fun renew() {
        val b = ByteArray(12).also { SecureRandom().nextBytes(it) }
        pass = b.joinToString("") { "%02x".format(it) }
    }
}

object Probe {
    private val trustAll = object : X509TrustManager {
        override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {}
        override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {}
        override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
    }

    /**
     * Étape 1 (avant de créer le VPN) : le serveur est-il joignable ?
     * On ne bloque QUE si le serveur est vraiment injoignable (adresse inconnue, délai dépassé, refus).
     * Les autres surprises (TLS, WebSocket) sont seulement écrites dans le journal.
     */
    fun reachable(p: Profile): String? {
        if (p.type == ProfileType.SSH) return null          // le tunnel SSH se connecte lui-même
        if (p.link.trim().startsWith("{")) return null      // configuration JSON complète : non testée
        val f = V2Form.fromLink(p.link)
        if (f.address.isBlank()) return "Adresse du serveur manquante"
        val port = f.port.toIntOrNull() ?: 443
        val raw = Socket()
        try {
            raw.connect(InetSocketAddress(f.address, port), 6000)
        } catch (e: UnknownHostException) {
            raw.close()
            return "Serveur introuvable : vérifie l'adresse ou ta connexion internet"
        } catch (e: SocketTimeoutException) {
            raw.close()
            return "Le serveur ne répond pas (délai dépassé)"
        } catch (e: Exception) {
            raw.close()
            return "Serveur injoignable : ${e.message ?: e.javaClass.simpleName}"
        }
        // Le serveur répond : on regarde de plus près, sans jamais bloquer
        try {
            raw.soTimeout = 5000
            var sock: Socket = raw
            if (f.tls == "tls" || f.tls == "reality") {
                val ctx = SSLContext.getInstance("TLS")
                ctx.init(null, arrayOf(trustAll), SecureRandom())
                val name = f.sni.ifBlank { f.host.ifBlank { f.address } }
                val ssl = ctx.socketFactory.createSocket(raw, name, port, true) as SSLSocket
                ssl.startHandshake()
                sock = ssl
            }
            if (f.network == "ws") {
                val path = f.path.ifBlank { "/" }.replace(" ", "%20")
                val host = f.host.ifBlank { f.address }
                val req = "GET $path HTTP/1.1\r\nHost: $host\r\nUpgrade: websocket\r\n" +
                    "Connection: Upgrade\r\nSec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\n" +
                    "Sec-WebSocket-Version: 13\r\n\r\n"
                sock.getOutputStream().write(req.toByteArray())
                sock.getOutputStream().flush()
                val line = BufferedReader(InputStreamReader(sock.getInputStream())).readLine()
                AppLog.add("Serveur joignable : ${line?.take(40) ?: "connexion fermée"}")
            } else {
                AppLog.add("Serveur joignable (${f.address}:$port)")
            }
        } catch (e: Exception) {
            AppLog.add("Serveur joignable, test détaillé non concluant : ${e.message ?: e.javaClass.simpleName}")
        } finally {
            try { raw.close() } catch (_: Exception) {}
        }
        return null
    }

    private fun readFully(inp: InputStream, buf: ByteArray) {
        var n = 0
        while (n < buf.size) {
            val r = inp.read(buf, n, buf.size - n)
            if (r < 0) throw java.io.IOException("fin de flux")
            n += r
        }
    }

    private val testTargets = listOf(
        "connectivitycheck.gstatic.com" to "/generate_204",
        "cp.cloudflare.com" to "/generate_204",
        "www.google.com" to "/generate_204"
    )

    /**
     * Étape 2 (après le démarrage de Xray) : vrai test de bout en bout.
     * Une requête passe par le proxy local, le tunnel puis ton serveur jusqu'à Internet.
     * Un seul site de test qui répond suffit.
     */
    fun viaProxy(timeoutMs: Int = 5000): Boolean =
        testTargets.any { (host, path) -> viaProxyTo(host, path, timeoutMs) }

    /** Ouvre une connexion TCP vers [targetHost]:[port] à travers le proxy local (donc à travers le tunnel). */
    private fun socksConnect(s: Socket, targetHost: String, port: Int, timeoutMs: Int): Boolean {
        s.connect(InetSocketAddress("127.0.0.1", TestProxy.PORT), 2000)
        s.soTimeout = timeoutMs
        val out = s.getOutputStream()
        val inp = s.getInputStream()
        out.write(byteArrayOf(5, 1, 2)); out.flush()
        val r1 = ByteArray(2); readFully(inp, r1)
        if (r1[1].toInt() != 2) return false
        val u = TestProxy.USER.toByteArray()
        val pw = TestProxy.pass.toByteArray()
        out.write(byteArrayOf(1, u.size.toByte()) + u + byteArrayOf(pw.size.toByte()) + pw); out.flush()
        val r2 = ByteArray(2); readFully(inp, r2)
        if (r2[1].toInt() != 0) return false
        val host = targetHost.toByteArray()
        out.write(byteArrayOf(5, 1, 0, 3, host.size.toByte()) + host + byteArrayOf((port shr 8).toByte(), port.toByte())); out.flush()
        val r3 = ByteArray(4); readFully(inp, r3)
        if (r3[1].toInt() != 0) return false
        when (r3[3].toInt()) {
            1 -> readFully(inp, ByteArray(6))
            4 -> readFully(inp, ByteArray(18))
            3 -> { val len = inp.read(); readFully(inp, ByteArray(len + 2)) }
        }
        return true
    }

    private fun viaProxyTo(targetHost: String, path: String, timeoutMs: Int): Boolean {
        return try {
            Socket().use { s ->
                if (!socksConnect(s, targetHost, 80, timeoutMs)) return false
                val out = s.getOutputStream()
                out.write("GET $path HTTP/1.1\r\nHost: $targetHost\r\nConnection: close\r\n\r\n".toByteArray())
                out.flush()
                val line = BufferedReader(InputStreamReader(s.getInputStream())).readLine() ?: return false
                line.startsWith("HTTP/")          // toute réponse HTTP prouve que le tunnel passe
            }
        } catch (_: Exception) {
            false
        }
    }

    /** Test de vitesse à travers le tunnel : téléchargement pendant ~8 s. Retourne des Mb/s, ou null. */
    fun speedTest(maxMs: Long = 8000): Double? {
        return try {
            Socket().use { s ->
                if (!socksConnect(s, "speed.cloudflare.com", 80, 4000)) return null
                val out = s.getOutputStream()
                out.write(
                    "GET /__down?bytes=30000000 HTTP/1.1\r\nHost: speed.cloudflare.com\r\nConnection: close\r\n\r\n"
                        .toByteArray()
                )
                out.flush()
                val inp = s.getInputStream()
                val buf = ByteArray(65536)
                var total = 0L
                val t0 = System.nanoTime()
                while (System.nanoTime() - t0 < maxMs * 1_000_000) {
                    val n = try { inp.read(buf) } catch (_: SocketTimeoutException) { -1 }
                    if (n < 0) break
                    total += n
                }
                val secs = (System.nanoTime() - t0) / 1e9
                if (total < 50_000 || secs < 0.3) null else total * 8 / secs / 1_000_000
            }
        } catch (_: Exception) {
            null
        }
    }
}
