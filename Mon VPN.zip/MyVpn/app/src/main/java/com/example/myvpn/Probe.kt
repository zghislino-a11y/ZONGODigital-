package com.example.myvpn

import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLException
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509TrustManager

/** Petit proxy SOCKS local (protégé par mot de passe) servant uniquement à tester la connexion. */
object TestProxy {
    const val PORT = 10809
    const val USER = "zng"
    @Volatile var pass: String = "zng"

    fun renew() {
        val b = ByteArray(12).also { SecureRandom().nextBytes(it) }
        pass = b.joinToString("") { "%02x".format(it) }
    }
}

object Probe {
    private val trustAll = object : X509TrustManager {
        override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {}
        override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {}
        override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
    }

    /**
     * Étape 1 (avant de créer le VPN) : le serveur répond-il vraiment ?
     * Retourne null si tout va bien, sinon un message d'erreur clair.
     */
    fun reachable(p: Profile): String? {
        if (p.type == ProfileType.SSH) return null          // le tunnel SSH se connecte lui-même
        if (p.link.trim().startsWith("{")) return null      // configuration JSON complète : non testée
        val f = V2Form.fromLink(p.link)
        if (f.address.isBlank()) return "Adresse du serveur manquante"
        val port = f.port.toIntOrNull() ?: 443
        return try {
            val raw = Socket()
            raw.connect(InetSocketAddress(f.address, port), 5000)
            raw.soTimeout = 5000
            var sock: Socket = raw
            if (f.tls == "tls" || f.tls == "reality") {
                val ctx = SSLContext.getInstance("TLS")
                ctx.init(null, arrayOf(trustAll), SecureRandom())
                val name = f.sni.ifBlank { f.host.ifBlank { f.address } }
                val ssl = ctx.socketFactory.createSocket(raw, name, port, true) as SSLSocket
                ssl.startHandshake()
                sock = ssl
            }
            sock.use { s ->
                if (f.network == "ws") {
                    val path = f.path.ifBlank { "/" }.replace(" ", "%20")
                    val host = f.host.ifBlank { f.address }
                    val req = "GET $path HTTP/1.1\r\nHost: $host\r\nUpgrade: websocket\r\n" +
                        "Connection: Upgrade\r\nSec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\n" +
                        "Sec-WebSocket-Version: 13\r\n\r\n"
                    s.getOutputStream().write(req.toByteArray())
                    s.getOutputStream().flush()
                    val line = BufferedReader(InputStreamReader(s.getInputStream())).readLine()
                    if (line == null) return "Le serveur a fermé la connexion (vérifie le path et le host)"
                    AppLog.add("Serveur joignable : ${line.take(40)}")
                } else {
                    AppLog.add("Serveur joignable (${f.address}:$port)")
                }
            }
            null
        } catch (e: UnknownHostException) {
            "Serveur introuvable : vérifie l'adresse ou ta connexion internet"
        } catch (e: SocketTimeoutException) {
            "Le serveur ne répond pas (délai dépassé)"
        } catch (e: SSLException) {
            "Échec de la connexion sécurisée : vérifie le SNI et le port"
        } catch (e: Exception) {
            "Serveur injoignable : ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private fun readFully(inp: InputStream, buf: ByteArray) {
        var n = 0
        while (n < buf.size) {
            val r = inp.read(buf, n, buf.size - n)
            if (r < 0) throw java.io.IOException("fin de flux")
            n += r
        }
    }

    /**
     * Étape 2 (après le démarrage de Xray) : vrai test de bout en bout.
     * Une requête passe par le proxy local, le tunnel puis ton serveur jusqu'à Internet.
     */
    fun viaProxy(timeoutMs: Int = 7000): Boolean {
        return try {
            Socket().use { s ->
                s.connect(InetSocketAddress("127.0.0.1", TestProxy.PORT), 2000)
                s.soTimeout = timeoutMs
                val out = s.getOutputStream()
                val inp = s.getInputStream()
                out.write(byteArrayOf(5, 1, 2)); out.flush()
                val r1 = ByteArray(2); readFully(inp, r1)
                if (r1[1].toInt() != 2) return false
                val u = TestProxy.USER.toByteArray()
                val pw = TestProxy.pass.toByteArray()
                out.write(byteArrayOf(1, u.size.toByte()) + u + byteArrayOf(pw.size.toByte()) + pw); out.flush()
                val r2 = ByteArray(2); readFully(inp, r2)
                if (r2[1].toInt() != 0) return false
                val host = "connectivitycheck.gstatic.com".toByteArray()
                out.write(byteArrayOf(5, 1, 0, 3, host.size.toByte()) + host + byteArrayOf(0, 80)); out.flush()
                val r3 = ByteArray(4); readFully(inp, r3)
                if (r3[1].toInt() != 0) return false
                when (r3[3].toInt()) {
                    1 -> readFully(inp, ByteArray(6))
                    4 -> readFully(inp, ByteArray(18))
                    3 -> { val len = inp.read(); readFully(inp, ByteArray(len + 2)) }
                }
                out.write(
                    "GET /generate_204 HTTP/1.1\r\nHost: connectivitycheck.gstatic.com\r\nConnection: close\r\n\r\n"
                        .toByteArray()
                )
                out.flush()
                val line = BufferedReader(InputStreamReader(inp)).readLine() ?: return false
                line.contains(" 204") || line.contains(" 200")
            }
        } catch (_: Exception) {
            false
        }
    }
}
