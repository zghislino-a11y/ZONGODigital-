package com.example.myvpn

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Sponsor(val title: String, val text: String, val url: String, val color: Int, val image: Bitmap?)

/**
 * Publicités / partenaires lus depuis un fichier sponsors.json à la racine du dépôt GitHub.
 * On change les pubs sans refaire l'application. Format :
 * {"sponsors":[{"title":"Boutique X","text":"-20 % sur tout","url":"https://wa.me/226…","image":"https://…/logo.png","color":"#1E40E0"}]}
 */
object Sponsors {
    const val REMOTE_URL = "https://raw.githubusercontent.com/zghislino-a11y/ZONGODigital-/main/sponsors.json"

    private fun fetch(url: String): ByteArray? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 5000; c.readTimeout = 5000
        return try {
            if (c.responseCode == 200) c.inputStream.use { it.readBytes() } else null
        } finally { c.disconnect() }
    }

    private fun decode(bytes: ByteArray): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1
        while (o.outWidth / sample > 256) sample *= 2
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    suspend fun load(ctx: Context): List<Sponsor> = withContext(Dispatchers.IO) {
        val prefs = ctx.getSharedPreferences("sponsors", Context.MODE_PRIVATE)
        val raw = try { fetch(REMOTE_URL)?.toString(Charsets.UTF_8) } catch (_: Exception) { null }
        val json = raw ?: prefs.getString("cache", null) ?: return@withContext emptyList()
        try {
            val arr = JSONObject(json).getJSONArray("sponsors")
            if (raw != null) prefs.edit().putString("cache", raw).apply()
            (0 until minOf(arr.length(), 5)).mapNotNull { i ->
                val o = arr.getJSONObject(i)
                val title = o.optString("title")
                if (title.isBlank()) return@mapNotNull null
                val color = try { android.graphics.Color.parseColor(o.optString("color", "#1E40E0")) } catch (_: Exception) { 0xFF1E40E0.toInt() }
                val image = o.optString("image").takeIf { it.startsWith("http") }?.let {
                    try { fetch(it)?.let(::decode) } catch (_: Exception) { null }
                }
                Sponsor(title, o.optString("text"), o.optString("url"), color, image)
            }
        } catch (_: Exception) { emptyList() }
    }
}
