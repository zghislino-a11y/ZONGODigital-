package com.example.myvpn

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

/**
 * Serveurs « officiels » de ZONGO Digital, affichés dans « Choisir un serveur ».
 * Ordre de lecture : 1) fichier en ligne (mis à jour sans recompiler l'app)
 *                    2) dernière copie en mémoire  3) fichier servers.txt de l'application.
 * Le fichier peut être en lignes « Nom|lien » ou un fichier « zongodigital:// » exporté depuis l'app.
 */
object OfficialServers {
    // Dépose un fichier servers.zongo (ou .txt) à la racine du dépôt GitHub pour mettre à jour les serveurs.
    const val REMOTE_URL = "https://raw.githubusercontent.com/zghislino-a11y/ZONGODigital-/main/servers.zongo"
    private const val PREFS = "official"

    suspend fun load(context: Context): List<Profile> = withContext(Dispatchers.IO) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val remote = try { fetch(REMOTE_URL) } catch (_: Exception) { null }
        val fromRemote = remote?.let { parse(it) }.orEmpty()
        if (fromRemote.isNotEmpty()) {
            prefs.edit().putString("cache", remote).apply()
            return@withContext fromRemote
        }
        val cached = prefs.getString("cache", null)?.let { parse(it) }.orEmpty()
        if (cached.isNotEmpty()) return@withContext cached
        val local = try {
            context.assets.open("servers.txt").bufferedReader().use { it.readText() }
        } catch (_: Exception) { "" }
        parse(local)
    }

    private fun fetch(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 5000; c.readTimeout = 5000
        return try {
            if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
        } finally { c.disconnect() }
    }

    fun parse(text: String): List<Profile> {
        val list = if (ZongoCodec.isZongo(text)) ZongoCodec.import(text)
        else text.lines().mapNotNull { line ->
            val l = line.trim()
            if (l.isEmpty() || l.startsWith("#") || !l.contains("|")) return@mapNotNull null
            val name = l.substringBefore("|").trim()
            val link = l.substringAfter("|").trim()
            if (name.isEmpty() || link.isEmpty()) return@mapNotNull null
            if (link.startsWith("ssh://")) {
                val u = Uri.parse(link)
                val info = u.userInfo ?: ""
                Profile(
                    name = name, type = ProfileType.SSH, host = u.host ?: return@mapNotNull null,
                    port = if (u.port > 0) u.port else 22,
                    user = info.substringBefore(":"), password = info.substringAfter(":", "")
                )
            } else Profile(name = name, type = ProfileType.V2RAY, link = link)
        }
        // Identifiants stables : le serveur choisi reste choisi après une mise à jour de la liste
        return list.map { it.copy(id = "official-" + (it.name + it.link + it.host).hashCode(), locked = true) }
    }
}

object Ping {
    private fun hostPort(p: Profile): Pair<String, Int>? =
        if (p.type == ProfileType.SSH) p.host.takeIf { it.isNotBlank() }?.let { it to p.port }
        else V2Form.fromLink(p.link).let { f ->
            if (f.address.isBlank()) null else f.address to (f.port.toIntOrNull() ?: 443)
        }

    /** Temps de connexion TCP en ms, ou null si le serveur ne répond pas. */
    suspend fun ms(p: Profile): Int? = withContext(Dispatchers.IO) {
        val (host, port) = hostPort(p) ?: return@withContext null
        try {
            val t0 = System.nanoTime()
            Socket().use { it.connect(InetSocketAddress(host, port), 3000) }
            ((System.nanoTime() - t0) / 1_000_000).toInt().coerceAtLeast(1)
        } catch (_: Exception) { null }
    }
}
