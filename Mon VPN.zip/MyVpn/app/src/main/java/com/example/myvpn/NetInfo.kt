package com.example.myvpn

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.telephony.TelephonyManager
import java.util.Locale

data class NetInfo(val operator: String, val type: String, val country: String)

/** Opérateur, type de connexion et pays du téléphone (le VPN n'est pas compté comme un réseau). */
object NetworkInfo {
    @Suppress("DEPRECATION")
    fun read(ctx: Context): NetInfo {
        val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        val operator = tm?.networkOperatorName.orEmpty().ifBlank { tm?.simOperatorName.orEmpty() }.ifBlank { "—" }
        val iso = tm?.networkCountryIso.orEmpty().ifBlank { tm?.simCountryIso.orEmpty() }.uppercase()
        val country = if (iso.length == 2) {
            val flag = iso.map { String(Character.toChars(0x1F1E6 + (it - 'A'))) }.joinToString("")
            "$flag ${Locale("", iso).getDisplayCountry(Locale.FRANCE)}"
        } else "—"

        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val caps = if (cm == null) emptyList() else try {
            cm.allNetworks.mapNotNull { cm.getNetworkCapabilities(it) }.filter {
                !it.hasTransport(NetworkCapabilities.TRANSPORT_VPN) &&
                    it.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            }
        } catch (_: Exception) { emptyList() }
        val type = when {
            caps.any { it.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) } -> "Wi-Fi"
            caps.any { it.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) } -> "Données mobiles"
            caps.any { it.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) } -> "Ethernet"
            else -> "Aucune connexion"
        }
        return NetInfo(operator, type, country)
    }
}
