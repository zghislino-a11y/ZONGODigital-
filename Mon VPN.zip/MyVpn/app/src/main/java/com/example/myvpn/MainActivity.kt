package com.example.myvpn

import android.content.Intent
import android.net.TrafficStats
import android.net.VpnService
import android.os.Bundle
import android.os.Process
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var pending: Profile? = null

    private val vpnPermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) pending?.let { startVpn(it) }
    }

    private fun connect(p: Profile) {
        pending = p
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermission.launch(intent) else startVpn(p)
    }

    private fun startVpn(p: Profile) {
        startService(
            Intent(this, MyVpnService::class.java)
                .setAction(MyVpnService.ACTION_START)
                .putExtra(MyVpnService.EXTRA_PROFILE, p.toJson().toString())
        )
    }

    private fun stopVpn() {
        startService(Intent(this, MyVpnService::class.java).setAction(MyVpnService.ACTION_STOP))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLog.init(applicationContext)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val store = ProfileStore(this)
        setContent { App(store, ::connect, ::stopVpn) }
    }
}

// ---------- Couleurs ----------
private val Bg = Color(0xFF040A18)
private val CardBg = Color(0xFF0B1630)
private val Line = Color(0xFF1B3A73)
private val Blue = Color(0xFF2F8CFF)
private val Cyan = Color(0xFF22D3EE)
private val Green = Color(0xFF22E39A)
private val Gold = Color(0xFFF5B301)
private val Muted = Color(0xFF8FA3C7)

private fun profileLabel(p: Profile): String =
    if (p.type == ProfileType.SSH) "SSH"
    else p.link.substringBefore("://", "V2RAY").uppercase().ifBlank { "V2RAY" }

private fun formatBytes(b: Long): String {
    val v = b.coerceAtLeast(0).toDouble()
    return when {
        v < 1024 -> "${v.toLong()} B"
        v < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", v / 1024)
        v < 1024.0 * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", v / (1024 * 1024))
        else -> String.format(Locale.US, "%.2f GB", v / (1024.0 * 1024 * 1024))
    }
}

private fun formatTime(s: Long) =
    String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)

@Composable
fun App(store: ProfileStore, onConnect: (Profile) -> Unit, onDisconnect: () -> Unit) {
    var profiles by remember { mutableStateOf(store.load()) }
    var selectedId by remember { mutableStateOf(profiles.firstOrNull()?.id) }
    var showAdd by remember { mutableStateOf(false) }
    var showLog by remember { mutableStateOf(false) }
    var showSsh by remember { mutableStateOf(false) }
    var showV2 by remember { mutableStateOf(false) }
    var v2Edit by remember { mutableStateOf<Profile?>(null) }

    val connectedId by VpnState.connected.collectAsState()
    val connecting by VpnState.connecting.collectAsState()
    val error by VpnState.error.collectAsState()

    val selected = profiles.firstOrNull { it.id == selectedId } ?: profiles.firstOrNull()
    val isOn = connectedId != null

    var seconds by remember { mutableStateOf(0L) }
    var sent by remember { mutableStateOf(0L) }
    var received by remember { mutableStateOf(0L) }

    LaunchedEffect(connectedId) {
        if (connectedId == null) {
            seconds = 0; sent = 0; received = 0
        } else {
            val uid = Process.myUid()
            val t0 = System.currentTimeMillis()
            val tx0 = TrafficStats.getUidTxBytes(uid).coerceAtLeast(0)
            val rx0 = TrafficStats.getUidRxBytes(uid).coerceAtLeast(0)
            while (true) {
                seconds = (System.currentTimeMillis() - t0) / 1000
                sent = TrafficStats.getUidTxBytes(uid) - tx0
                received = TrafficStats.getUidRxBytes(uid) - rx0
                delay(1000)
            }
        }
    }

    val accent = when {
        isOn -> Green
        connecting -> Gold
        else -> Blue
    }
    val statusText = when {
        isOn -> "CONNECTÉ"
        connecting -> "CONNEXION…"
        else -> "DÉCONNECTÉ"
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue, background = Bg, surface = CardBg,
            onSurface = Color.White, onBackground = Color.White,
            error = Color(0xFFFF5C6C)
        )
    ) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            Column(
                Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // En-tête
                Row(
                    Modifier.fillMaxWidth().padding(top = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LogoMark(Modifier.size(38.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("ZONGO Digital", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { showLog = true }) { Text("Journal", color = Cyan) }
                }

                Spacer(Modifier.height(28.dp))
                PowerButton(accent) {
                    when {
                        isOn || connecting -> onDisconnect()
                        selected != null -> onConnect(selected)
                        else -> showAdd = true
                    }
                }
                Spacer(Modifier.height(22.dp))
                Text(
                    statusText, color = accent, fontSize = 22.sp,
                    fontWeight = FontWeight.Bold, letterSpacing = 4.sp
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    if (selected != null) "Serveur actif : ${selected.name}" else "Aucun serveur",
                    color = Color.White, fontSize = 14.sp
                )
                error?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Erreur : $it", color = MaterialTheme.colorScheme.error,
                        fontSize = 13.sp, textAlign = TextAlign.Center
                    )
                }

                Spacer(Modifier.height(24.dp))

                // Statistiques
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                        .background(CardBg).border(1.dp, Line, RoundedCornerShape(22.dp)).padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("TEMPS DE CONNEXION", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(formatTime(seconds), color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Light)
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatTile("▲ ENVOYÉ", formatBytes(sent), Cyan, Modifier.weight(1f))
                        StatTile("▼ REÇU", formatBytes(received), Green, Modifier.weight(1f))
                    }
                }

                Spacer(Modifier.height(24.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("MES SERVEURS", color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Spacer(Modifier.weight(1f))
                    Text("${profiles.size}", color = Muted)
                }
                Spacer(Modifier.height(10.dp))

                if (profiles.isEmpty()) {
                    Text("Aucun serveur. Appuie sur + pour en ajouter un.", color = Muted, fontSize = 14.sp)
                }
                profiles.forEach { p ->
                    val isSel = p.id == selected?.id
                    Row(
                        Modifier.fillMaxWidth().padding(bottom = 10.dp)
                            .clip(RoundedCornerShape(18.dp)).background(CardBg)
                            .border(if (isSel) 2.dp else 1.dp, if (isSel) accent else Line, RoundedCornerShape(18.dp))
                            .clickable { selectedId = p.id }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.clip(RoundedCornerShape(12.dp)).background(Blue)
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) { Text(profileLabel(p), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            Text(
                                if (p.type == ProfileType.SSH) "${p.host}:${p.port}" else v2Summary(p),
                                color = Muted, fontSize = 12.sp
                            )
                        }
                        if (p.type == ProfileType.V2RAY) {
                            TextButton(onClick = { v2Edit = p; showV2 = true }) {
                                Text("Modifier", color = Green, fontSize = 12.sp)
                            }
                        }
                        TextButton(onClick = {
                            profiles = profiles.filter { it.id != p.id }.also(store::save)
                        }) { Text("Supprimer", color = Color(0xFFFF5C6C), fontSize = 12.sp) }
                    }
                }
                Spacer(Modifier.height(100.dp))
            }

            FloatingActionButton(
                onClick = { showAdd = true },
                containerColor = Blue, contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(20.dp)
            ) { Text("+", fontSize = 28.sp) }
        }

        if (showAdd) {
            AlertDialog(
                onDismissRequest = { showAdd = false },
                title = { Text("Ajouter un serveur") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { showAdd = false; v2Edit = null; showV2 = true },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)
                        ) { Text("V2Ray (vmess / vless)") }
                        Button(
                            onClick = { showAdd = false; showSsh = true },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("SSH") }
                    }
                },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Annuler") } }
            )
        }
        if (showSsh) {
            AddProfileDialog(
                onDismiss = { showSsh = false },
                onSave = { p ->
                    profiles = (profiles + p).also(store::save)
                    selectedId = p.id
                    showSsh = false
                }
            )
        }
        if (showV2) {
            V2Editor(
                initial = v2Edit,
                onDismiss = { showV2 = false },
                onSave = { p ->
                    val updated =
                        if (profiles.any { it.id == p.id }) profiles.map { if (it.id == p.id) p else it }
                        else profiles + p
                    profiles = updated
                    store.save(updated)
                    selectedId = p.id
                    showV2 = false
                }
            )
        }
        if (showLog) LogDialog { showLog = false }
    }
}

@Composable
fun StatTile(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xFF0F1E3F)).padding(14.dp)
    ) {
        Text(title, color = color, fontSize = 11.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(4.dp))
        Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Gros bouton rond avec halo lumineux et icône marche/arrêt dessinée à la main. */
@Composable
fun PowerButton(color: Color, onClick: () -> Unit) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(230.dp)) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(listOf(color.copy(alpha = 0.35f), Color.Transparent)), CircleShape
            )
        )
        Box(
            Modifier.size(170.dp).clip(CircleShape).background(Color(0xFF07122B))
                .border(5.dp, color, CircleShape).clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(70.dp)) {
                val w = size.width
                val stroke = w * 0.1f
                drawArc(
                    color = Color.White, startAngle = -60f, sweepAngle = 300f, useCenter = false,
                    topLeft = Offset(w * 0.1f, w * 0.16f), size = Size(w * 0.8f, w * 0.8f),
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
                drawLine(
                    Color.White, Offset(w / 2, w * 0.04f), Offset(w / 2, w * 0.5f),
                    strokeWidth = stroke, cap = StrokeCap.Round
                )
            }
        }
    }
}

/** Logo : fond bleu nuit, lettre Z dorée (même dessin que l'icône de l'application). */
@Composable
fun LogoMark(modifier: Modifier = Modifier) {
    Canvas(modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFF0B1F4A))) {
        val w = size.width
        val h = size.height
        fun px(x: Float) = w * (0.2f + 0.6f * (x - 34f) / 40f)
        fun py(y: Float) = h * (0.22f + 0.56f * (y - 36f) / 38f)
        val z = Path().apply {
            moveTo(px(34f), py(36f)); lineTo(px(74f), py(36f)); lineTo(px(74f), py(44f))
            lineTo(px(48f), py(66f)); lineTo(px(74f), py(66f)); lineTo(px(74f), py(74f))
            lineTo(px(34f), py(74f)); lineTo(px(34f), py(66f)); lineTo(px(60f), py(44f))
            lineTo(px(34f), py(44f)); close()
        }
        drawPath(z, Gold)
    }
}

@Composable
fun LogDialog(onDismiss: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    val text = remember { AppLog.tail() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Journal") },
        text = {
            Box(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                Text(
                    text.ifBlank { "(vide) Lance une connexion puis rouvre le journal." },
                    fontFamily = FontFamily.Monospace, fontSize = 10.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { clipboard.setText(AnnotatedString(text)) }) { Text("Copier") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}

@Composable
fun AddProfileDialog(onDismiss: () -> Unit, onSave: (Profile) -> Unit) {
    var type by remember { mutableStateOf(ProfileType.SSH) }
    var name by remember { mutableStateOf("") }
    var host by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("22") }
    var user by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nouveau serveur SSH") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true)
                if (type == ProfileType.SSH) {
                    OutlinedTextField(host, { host = it }, label = { Text("Serveur") }, singleLine = true)
                    OutlinedTextField(port, { port = it }, label = { Text("Port") }, singleLine = true)
                    OutlinedTextField(user, { user = it }, label = { Text("Utilisateur") }, singleLine = true)
                    OutlinedTextField(password, { password = it }, label = { Text("Mot de passe") }, singleLine = true)
                } else {
                    OutlinedTextField(link, { link = it }, label = { Text("Lien vmess:// vless:// …") })
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = {
                    onSave(
                        Profile(
                            name = name.trim(), type = type,
                            host = host.trim(), port = port.toIntOrNull() ?: 22,
                            user = user.trim(), password = password, link = link.trim()
                        )
                    )
                }
            ) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}
