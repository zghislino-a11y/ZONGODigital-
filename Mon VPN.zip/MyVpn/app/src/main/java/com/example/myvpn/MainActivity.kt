package com.example.myvpn

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import android.net.TrafficStats
import android.net.VpnService
import android.os.Bundle
import android.os.Process
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var pending: Profile? = null

    private val vpnPermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) pending?.let { startVpn(it) }
    }

    private fun connect(p: Profile) {
        pending = p
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermission.launch(intent) else startVpn(p)
    }

    private fun startVpn(p: Profile) {
        startService(
            Intent(this, MyVpnService::class.java)
                .setAction(MyVpnService.ACTION_START)
                .putExtra(MyVpnService.EXTRA_PROFILE, p.toJson().toString())
        )
    }

    private fun stopVpn() {
        startService(Intent(this, MyVpnService::class.java).setAction(MyVpnService.ACTION_STOP))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLog.init(applicationContext)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val store = ProfileStore(this)
        setContent { App(store, ::connect, ::stopVpn) }
    }
}

// ---------- Couleurs ----------
private val Bg = Color(0xFF0D0D10)
private val CardBg = Color(0xFF1A1B20)
private val Line = Color(0xFF2C2E36)
private val Blue = Color(0xFFFFC107)
private val Cyan = Color(0xFF22D3EE)
private val Green = Color(0xFF22E39A)
private val Gold = Color(0xFFF5B301)
private val Muted = Color(0xFF9AA0AE)
private val Purple = Color(0xFF8B5CF6)
private val Orange = Color(0xFFF97316)
private val BgTop = Color(0xFF0D0D10)

private fun badgeColor(label: String): Color = when (label) {
    "VMESS" -> Blue
    "VLESS" -> Purple
    "TROJAN" -> Orange
    "SSH" -> Color(0xFF16A34A)
    else -> Blue
}

private fun transportLabel(net: String) = when (net) {
    "ws" -> "Websocket"
    "grpc" -> "gRPC"
    "httpupgrade" -> "HTTPUpgrade"
    "xhttp", "splithttp" -> "XHTTP"
    "kcp" -> "mKCP"
    "tcp" -> "TCP"
    else -> net.uppercase()
}

private fun configHeader(p: Profile): String {
    if (p.type == ProfileType.SSH) return "SSH"
    val f = V2Form.fromLink(p.link)
    val proto = when (f.protocol) {
        "vmess" -> "VMess"; "vless" -> "VLess"; "trojan" -> "Trojan"; else -> f.protocol
    }
    val tls = if (f.tls == "tls" || f.tls == "reality") " SSL/TLS" else ""
    return "$proto  •  ${transportLabel(f.network)}$tls"
}

private fun configFields(p: Profile): List<Pair<String, String>> {
    if (p.locked) return listOf("serveur" to p.name, "accès" to "🔒 Serveur protégé")
    if (p.type == ProfileType.SSH) return listOf("serveur cible" to "${p.host}:${p.port}", "utilisateur" to p.user)
    val f = V2Form.fromLink(p.link)
    return listOf(
        "serveur cible" to "${f.address}:${f.port}",
        (if (f.protocol == "trojan") "mot de passe" else "uuid") to f.id,
        "path" to f.path,
        "server name indication" to f.sni,
        "header host" to f.host
    ).filter { it.second.isNotBlank() }
}

/** Attente avant de lancer la connexion (en secondes). */
private const val CONNECT_DELAY_S = 5

private fun profileLabel(p: Profile): String =
    if (p.type == ProfileType.SSH) "SSH"
    else p.link.substringBefore("://", "V2RAY").uppercase().ifBlank { "V2RAY" }

private fun formatBytes(b: Long): String {
    val v = b.coerceAtLeast(0).toDouble()
    return when {
        v < 1024 -> "${v.toLong()} B"
        v < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", v / 1024)
        v < 1024.0 * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", v / (1024 * 1024))
        else -> String.format(Locale.US, "%.2f GB", v / (1024.0 * 1024 * 1024))
    }
}

private fun formatSpeed(bytesPerSec: Long): String {
    val v = bytesPerSec.coerceAtLeast(0).toDouble()
    return if (v < 1024 * 1024) String.format(Locale.US, "%.0f Ko/s", v / 1024)
    else String.format(Locale.US, "%.1f Mo/s", v / (1024 * 1024))
}

private fun formatTime(s: Long) =
    String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)

@Composable
fun App(store: ProfileStore, onConnect: (Profile) -> Unit, onDisconnect: () -> Unit) {
    var profiles by remember { mutableStateOf(store.load()) }
    var selectedId by remember { mutableStateOf(profiles.firstOrNull()?.id) }
    var showAdd by remember { mutableStateOf(false) }
    var showLog by remember { mutableStateOf(false) }
    var showSsh by remember { mutableStateOf(false) }
    var showV2 by remember { mutableStateOf(false) }
    var v2Edit by remember { mutableStateOf<Profile?>(null) }
    var v2Preset by remember { mutableStateOf("vmess") }
    var toDelete by remember { mutableStateOf<Profile?>(null) }
    var showPicker by remember { mutableStateOf(false) }
    var showFiles by remember { mutableStateOf(false) }
    var showPaste by remember { mutableStateOf(false) }
    var showExpiry by remember { mutableStateOf(false) }
    var exportMode by remember { mutableStateOf("file") }
    var exportExp by remember { mutableStateOf(0L) }
    var official by remember { mutableStateOf<List<Profile>>(emptyList()) }
    var menuPage by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf(0) }
    val consoleScroll = rememberScrollState()
    var showAbout by remember { mutableStateOf(false) }
    var logText by remember { mutableStateOf("") }
    var counting by remember { mutableStateOf(false) }
    var countdown by remember { mutableStateOf(0) }

    val connectedId by VpnState.connected.collectAsState()
    val connecting by VpnState.connecting.collectAsState()
    val error by VpnState.error.collectAsState()

    val ctx = LocalContext.current
    var nowMs by remember { mutableStateOf(Expiry.now(ctx)) }
    var net by remember { mutableStateOf(NetworkInfo.read(ctx)) }
    LaunchedEffect(Unit) { while (true) { net = NetworkInfo.read(ctx); delay(5_000) } }
    var pingText by remember { mutableStateOf<String?>(null) }
    val clipboard = LocalClipboardManager.current
    LaunchedEffect(Unit) { while (true) { logText = AppLog.tail(4000); delay(1000) } }
    LaunchedEffect(logText) { consoleScroll.scrollTo(consoleScroll.maxValue) }
    var update by remember { mutableStateOf<UpdateInfo?>(null) }
    LaunchedEffect(Unit) { update = UpdateChecker.check(ctx) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { while (true) { delay(60_000); nowMs = Expiry.now(ctx) } }
    LaunchedEffect(Unit) { official = OfficialServers.load(ctx) }
    val all = official + profiles
    val selected = all.firstOrNull { it.id == selectedId } ?: all.firstOrNull()
    LaunchedEffect(selected?.id) { pingText = null }

    fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
    // Retourne (réussi, message)
    fun addImported(text: String): Pair<Boolean, String> {
        val list = ZongoCodec.import(text)
        if (list.isEmpty()) return false to "Fichier non reconnu"
        val exp = list.first().expiresAt
        nowMs = Expiry.now(ctx)
        if (exp > 0 && nowMs > exp) return false to "Ce fichier a expiré le ${Expiry.format(exp)}"
        profiles = (profiles + list).also(store::save)
        selectedId = list.first().id
        VpnState.error.value = null
        return true to if (exp > 0) "Serveurs importés ✓ (valables jusqu'au ${Expiry.format(exp)})" else "Serveurs importés ✓"
    }
    val exportable = profiles.filter { !it.locked }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = try {
                ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            } catch (_: Exception) { null }
            toast(if (text == null) "Fichier illisible" else addImported(text).second)
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(ZongoCodec.export(exportable, exportExp)) }
                toast("Fichier enregistré ✓")
            } catch (_: Exception) { toast("Échec de l'enregistrement") }
        }
    }
    val isOn = connectedId != null
    val latestSelected by rememberUpdatedState(selected)

    // Compte à rebours de 5 secondes, puis connexion
    LaunchedEffect(counting) {
        if (counting) {
            for (i in CONNECT_DELAY_S downTo 1) {
                countdown = i
                delay(1000)
            }
            counting = false
            countdown = 0
            latestSelected?.let {
                if (Expiry.isExpired(it, Expiry.now(ctx))) VpnState.error.value = Expiry.MESSAGE
                else onConnect(it)
            }
        }
    }

    var seconds by remember { mutableStateOf(0L) }
    var sent by remember { mutableStateOf(0L) }
    var received by remember { mutableStateOf(0L) }
    var upSpeed by remember { mutableStateOf(0L) }
    var downSpeed by remember { mutableStateOf(0L) }

    LaunchedEffect(connectedId) {
        if (connectedId == null) {
            seconds = 0; sent = 0; received = 0; upSpeed = 0; downSpeed = 0
        } else {
            val uid = Process.myUid()
            val t0 = System.currentTimeMillis()
            val tx0 = TrafficStats.getUidTxBytes(uid).coerceAtLeast(0)
            val rx0 = TrafficStats.getUidRxBytes(uid).coerceAtLeast(0)
            var prevS = 0L
            var prevR = 0L
            while (true) {
                seconds = (System.currentTimeMillis() - t0) / 1000
                val s = TrafficStats.getUidTxBytes(uid) - tx0
                val r = TrafficStats.getUidRxBytes(uid) - rx0
                upSpeed = (s - prevS).coerceAtLeast(0)
                downSpeed = (r - prevR).coerceAtLeast(0)
                prevS = s; prevR = r
                sent = s; received = r
                delay(1000)
            }
        }
    }

    val accent = when {
        isOn -> Green
        connecting || counting -> Gold
        else -> Blue
    }
    val statusText = when {
        isOn -> "CONNECTÉ"
        counting -> "CONNEXION DANS ${countdown}s"
        connecting -> "CONNEXION…"
        else -> "DÉCONNECTÉ"
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue, onPrimary = Color.Black, background = Bg, surface = CardBg,
            surfaceContainerHigh = Color(0xFF22242A), onSurfaceVariant = Muted,
            onSurface = Color.White, onBackground = Color.White,
            error = Color(0xFFFF5C6C)
        )
    ) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                // ----- Barre du haut -----
                Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
                // Barre du haut (style DarkTunnel)
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LogoMark(Modifier.size(34.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("ZONGO Digital", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.weight(1f))
                    Box(Modifier.size(42.dp).clickable { showAbout = true }, contentAlignment = Alignment.Center) {
                        Text("♥", color = Color(0xFFE5484D), fontSize = 24.sp)
                    }
                    Box(
                        Modifier.size(42.dp).clickable { AppLog.reset(); logText = ""; toast("Journal vidé") },
                        contentAlignment = Alignment.Center
                    ) { Text("🗑", fontSize = 20.sp) }
                    Box {
                        Box(Modifier.size(42.dp).clickable { menuPage = "root" }, contentAlignment = Alignment.Center) {
                            Text("⋮", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        }
                        DropdownMenu(expanded = menuPage != null, onDismissRequest = { menuPage = null }) {
                            fun needServers(): Boolean {
                                if (exportable.isEmpty()) { toast("Ajoute d'abord un serveur"); return false }
                                return true
                            }
                            when (menuPage) {
                                "config" -> {
                                    MenuRow("◂  Config", muted = true) { menuPage = "root" }
                                    MenuRow("Nouveau") { menuPage = null; showAdd = true }
                                    MenuRow("Importer", arrow = true) { menuPage = "import" }
                                    MenuRow("Exporter", arrow = true) { menuPage = "export" }
                                }
                                "import" -> {
                                    MenuRow("◂  Importer", muted = true) { menuPage = "config" }
                                    MenuRow("Presse-papiers") {
                                        menuPage = null
                                        val t = clipboard.getText()?.text?.trim().orEmpty()
                                        if (t.startsWith("vmess://") || t.startsWith("vless://") || t.startsWith("trojan://")) {
                                            val f = V2Form.fromLink(t)
                                            val name = f.name.ifBlank { f.address.ifBlank { "V2Ray" } }
                                            val np = Profile(name = name, type = ProfileType.V2RAY, link = f.copy(name = name).toLink())
                                            profiles = (profiles + np).also(store::save)
                                            selectedId = np.id
                                            toast("Serveur importé ✓")
                                        } else {
                                            toast(addImported(t).second)
                                        }
                                    }
                                    MenuRow("Fichier") { menuPage = null; importLauncher.launch(arrayOf("*/*")) }
                                }
                                "export" -> {
                                    MenuRow("◂  Exporter", muted = true) { menuPage = "config" }
                                    MenuRow("Fichier") {
                                        menuPage = null
                                        if (needServers()) { exportMode = "file"; showExpiry = true }
                                    }
                                    MenuRow("Partager (texte)") {
                                        menuPage = null
                                        if (needServers()) { exportMode = "share"; showExpiry = true }
                                    }
                                }
                                "tunnel" -> {
                                    MenuRow("◂  Type de tunnel", muted = true) { menuPage = "root" }
                                    MenuRow("SSH") { menuPage = null; showSsh = true }
                                    MenuRow("VMess") { menuPage = null; v2Edit = null; v2Preset = "vmess"; showV2 = true }
                                    MenuRow("VLess") { menuPage = null; v2Edit = null; v2Preset = "vless"; showV2 = true }
                                    MenuRow("Trojan") { menuPage = null; v2Edit = null; v2Preset = "trojan"; showV2 = true }
                                }
                                "community" -> {
                                    MenuRow("◂  Communauté", muted = true) { menuPage = "root" }
                                    MenuRow("WhatsApp ZNG") {
                                        menuPage = null
                                        try {
                                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/22657544635")))
                                        } catch (_: Exception) { toast("WhatsApp indisponible") }
                                    }
                                    MenuRow("Appeler ZNG") {
                                        menuPage = null
                                        ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:+22657544635")))
                                    }
                                }
                                else -> {
                                    MenuRow("Config", arrow = true) { menuPage = "config" }
                                    MenuRow("Type de tunnel", arrow = true) { menuPage = "tunnel" }
                                    MenuRow("Communauté", arrow = true) { menuPage = "community" }
                                    MenuRow("Journal") { menuPage = null; showLog = true }
                                    MenuRow("À propos") { menuPage = null; showAbout = true }
                                }
                            }
                        }
                    }
                }

                }

                // ----- Contenu de l'onglet choisi (pas de long défilement) -----
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (tab) {
                        0 -> Column(
                            Modifier.fillMaxSize().padding(horizontal = 20.dp).padding(bottom = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Bannière compacte (touche = WhatsApp)
                            Row(
                                Modifier.fillMaxWidth().padding(top = 8.dp)
                                    .clip(RoundedCornerShape(12.dp)).background(Color(0xFF1A1405))
                                    .border(1.dp, Gold.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                                    .clickable {
                                        try {
                                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/22657544635")))
                                        } catch (_: Exception) { toast("WhatsApp indisponible") }
                                    }
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text("📢 D'ici, les publicités arrivent", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text("Contacter ZNG : +226 57 54 46 35", color = Color.White, fontSize = 12.sp)
                                }
                                Text("💬", fontSize = 22.sp)
                            }
                            Spacer(Modifier.height(12.dp))

                // Carte de configuration (style DarkTunnel) : toucher pour choisir un serveur
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(CardBg)
                        .clickable { if (!isOn && !connecting && !counting) showPicker = true }
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    if (selected == null) {
                        Text("Aucun serveur — touche ici pour en choisir ou en ajouter", color = Muted, fontSize = 14.sp)
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(configHeader(selected), color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                            Box(
                                Modifier.clip(RoundedCornerShape(10.dp)).background(Blue)
                                    .clickable {
                                        selected?.let { sv ->
                                            scope.launch {
                                                pingText = "…"
                                                val r = Ping.ms(sv)
                                                pingText = if (r == null) "Hors ligne" else "$r ms"
                                            }
                                        }
                                    }
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) { Text(pingText ?: "⚡ PING", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        }
                        configFields(selected).forEach { (k, v) ->
                            Spacer(Modifier.height(4.dp))
                            Text(k, color = Muted, fontSize = 11.sp)
                            Text(v, color = Color.White, fontSize = 15.sp, maxLines = 1)
                            Spacer(Modifier.height(4.dp))
                            Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
                        }
                        if (selected.expiresAt > 0) {
                            val exp = Expiry.isExpired(selected, nowMs)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                (if (exp) "Expiré le " else "Expire le ") + Expiry.format(selected.expiresAt),
                                color = if (exp) Color(0xFFFF5C6C) else Gold, fontSize = 12.sp
                            )
                        }
                    }
                }

                // Gros bouton CONNECTER (avec compte à rebours de 5 secondes)
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = {
                        when {
                            isOn || connecting -> onDisconnect()
                            counting -> { counting = false; countdown = 0 }
                            selected != null && Expiry.isExpired(selected, nowMs) -> VpnState.error.value = Expiry.MESSAGE
                            selected != null -> counting = true
                            else -> showAdd = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isOn) Color(0xFFE5484D) else Blue,
                        contentColor = if (isOn) Color.White else Color.Black
                    )
                ) {
                    Text(
                        when {
                            isOn -> "DÉCONNECTER"
                            connecting -> "ANNULER"
                            counting -> "CONNEXION DANS ${countdown}s — ANNULER"
                            else -> "CONNECTER"
                        },
                        fontSize = 16.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "● " + when {
                        isOn -> "Connecté"
                        counting -> "Connexion dans ${countdown}s…"
                        connecting -> "Connexion…"
                        else -> "Déconnecté"
                    },
                    color = accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold
                )
                error?.let {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (it == Expiry.MESSAGE) it else "Erreur : $it", color = MaterialTheme.colorScheme.error,
                        fontSize = 13.sp, textAlign = TextAlign.Center
                    )
                }

                // Console (journal en direct)
                Spacer(Modifier.height(10.dp))
                val logLines = logText.lines().filter { it.isNotBlank() }.takeLast(40)
                Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(consoleScroll)) {
                    if (logLines.isEmpty()) {
                        Text(
                            "Le journal de connexion s'affichera ici.", color = Muted,
                            fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp)
                        )
                    }
                    logLines.forEach { l ->
                        Text(
                            l, color = Color(0xFFD0D3DC), fontFamily = FontFamily.Monospace, fontSize = 11.sp,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                        )
                        Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
                    }
                }

                        }
                        1 -> Column(
                            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)
                        ) {
                            Spacer(Modifier.height(12.dp))
                Spacer(Modifier.height(24.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("MES SERVEURS", color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Spacer(Modifier.weight(1f))
                    Text("${all.size}", color = Muted)
                    TextButton(onClick = { showAdd = true }) { Text("+ Ajouter", color = Blue, fontWeight = FontWeight.Bold) }
                }
                Spacer(Modifier.height(10.dp))

                if (all.isEmpty()) {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CardBg)
                            .border(1.dp, Line, RoundedCornerShape(20.dp)).padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Aucun serveur pour le moment", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { showAdd = true }, shape = RoundedCornerShape(14.dp)) {
                            Text("+ Ajouter un serveur")
                        }
                    }
                }
                all.forEach { p ->
                    val isSel = p.id == selected?.id
                    val label = profileLabel(p)
                    Column(
                        Modifier.fillMaxWidth().padding(bottom = 12.dp)
                            .clip(RoundedCornerShape(20.dp)).background(CardBg)
                            .border(if (isSel) 2.dp else 1.dp, if (isSel) accent else Line, RoundedCornerShape(20.dp))
                            .clickable { selectedId = p.id }
                            .padding(start = 14.dp, end = 6.dp, top = 12.dp, bottom = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.clip(RoundedCornerShape(12.dp)).background(badgeColor(label))
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) { Text(label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                                Text(
                                    if (p.locked) "🔒 Serveur protégé"
                                    else if (p.type == ProfileType.SSH) "${p.host}:${p.port}" else v2Summary(p),
                                    color = Muted, fontSize = 12.sp, maxLines = 1
                                )
                                if (p.expiresAt > 0) {
                                    val ex = Expiry.isExpired(p, nowMs)
                                    Text(
                                        (if (ex) "Expiré le " else "Expire le ") + Expiry.format(p.expiresAt),
                                        color = if (ex) Color(0xFFFF5C6C) else Gold, fontSize = 12.sp
                                    )
                                }
                            }
                            if (isSel) {
                                Box(
                                    Modifier.padding(end = 8.dp).size(24.dp).clip(CircleShape).background(accent),
                                    contentAlignment = Alignment.Center
                                ) { Text("✓", color = Color.Black, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                            }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            if (p.type == ProfileType.V2RAY && !p.locked) {
                                TextButton(onClick = { v2Edit = p; showV2 = true }) {
                                    Text("Modifier", color = Green, fontSize = 12.sp)
                                }
                            }
                            if (!p.id.startsWith("official-")) {
                                TextButton(onClick = { toDelete = p }) {
                                    Text("Supprimer", color = Color(0xFFFF5C6C), fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
                            Spacer(Modifier.height(24.dp))
                        }
                        2 -> Column(
                            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)
                        ) {
                            Spacer(Modifier.height(14.dp))
                // Statistiques
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                        .background(CardBg).border(1.dp, Line, RoundedCornerShape(22.dp)).padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("TEMPS DE CONNEXION", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(formatTime(seconds), color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Light)
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatTile("▲ ENVOYÉ", formatBytes(sent), Cyan, Modifier.weight(1f), formatSpeed(upSpeed))
                        StatTile("▼ REÇU", formatBytes(received), Green, Modifier.weight(1f), formatSpeed(downSpeed))
                    }
                }

                            Spacer(Modifier.height(16.dp))
                // Informations réseau
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                        .background(CardBg).border(1.dp, Line, RoundedCornerShape(22.dp)).padding(18.dp)
                ) {
                    Text("📶 INFORMATIONS RÉSEAU", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Spacer(Modifier.height(10.dp))
                    listOf("Opérateur" to net.operator, "Connexion" to net.type, "Pays" to net.country).forEach { (k, v) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                            Text(k, color = Muted, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            Text(v, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                            Spacer(Modifier.height(24.dp))
                        }
                        else -> Column(
                            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)
                        ) {
                            Spacer(Modifier.height(14.dp))
                            PlusItem("💬", "WhatsApp ZNG", "+226 57 54 46 35") {
                                try {
                                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/22657544635")))
                                } catch (_: Exception) { toast("WhatsApp indisponible") }
                            }
                            PlusItem("📞", "Appeler ZNG", "+226 57 54 46 35") {
                                ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:+22657544635")))
                            }
                            PlusItem("📁", "Fichiers .zongo", "Importer, exporter ou coller un code") { showFiles = true }
                            PlusItem("📜", "Journal complet", "Voir et copier le journal") { showLog = true }
                            PlusItem("ℹ️", "À propos", "Version ${UpdateChecker.installedName(ctx)}") { showAbout = true }
                            Spacer(Modifier.height(16.dp))
                            Text(
                                "ZONGO Digital · v${UpdateChecker.installedName(ctx)}", color = Muted, fontSize = 11.sp,
                                modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
                            )
                            Spacer(Modifier.height(24.dp))
                        }
                    }
                }

                // ----- Barre d'onglets en bas -----
                NavigationBar(containerColor = CardBg) {
                    listOf("🏠" to "Accueil", "🖥" to "Serveurs", "📊" to "Stats", "⚙" to "Plus").forEachIndexed { i, (ic, label) ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(ic, fontSize = 20.sp) },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedTextColor = Blue, unselectedTextColor = Muted,
                                indicatorColor = Color(0xFF2E2810)
                            )
                        )
                    }
                }
            }
        }

        if (showAdd) {
            AlertDialog(
                onDismissRequest = { showAdd = false },
                title = { Text("Ajouter un serveur") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { showAdd = false; v2Edit = null; v2Preset = "vmess"; showV2 = true },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)
                        ) { Text("V2Ray (vmess / vless)") }
                        Button(
                            onClick = { showAdd = false; v2Edit = null; v2Preset = "trojan"; showV2 = true },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.White)
                        ) { Text("Trojan") }
                        Button(
                            onClick = { showAdd = false; showSsh = true },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("SSH") }
                        OutlinedButton(
                            onClick = { showAdd = false; showFiles = true },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Fichier .zongo (importer / exporter)") }
                    }
                },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Annuler") } }
            )
        }
        toDelete?.let { d ->
            AlertDialog(
                onDismissRequest = { toDelete = null },
                title = { Text("Supprimer ce serveur ?") },
                text = { Text(d.name) },
                confirmButton = {
                    TextButton(onClick = {
                        profiles = profiles.filter { it.id != d.id }.also(store::save)
                        toDelete = null
                    }) { Text("Supprimer", color = Color(0xFFFF5C6C)) }
                },
                dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Annuler") } }
            )
        }
        update?.let { u ->
            AlertDialog(
                onDismissRequest = { if (!u.force) update = null },
                title = { Text("Nouvelle version ${u.versionName}") },
                text = {
                    Text(
                        if (u.notes.isNotBlank()) u.notes else "Une mise à jour est disponible.",
                        color = Muted, fontSize = 14.sp
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u.url))) }
                        catch (_: Exception) { toast("Impossible d'ouvrir le lien") }
                    }) { Text("Télécharger", fontWeight = FontWeight.Bold) }
                },
                dismissButton = { if (!u.force) TextButton(onClick = { update = null }) { Text("Plus tard") } }
            )
        }
        if (showAbout) {
            AlertDialog(
                onDismissRequest = { showAbout = false },
                title = { Text("ZONGO Digital") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Version ${UpdateChecker.installedName(ctx)}", color = Muted, fontSize = 13.sp)
                        Text("Contact ZNG : +226 57 54 46 35", color = Color.White, fontSize = 15.sp)
                        Text("D'ici, les publicités arrivent. Merci de soutenir l'application ♥", color = Muted, fontSize = 13.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        showAbout = false
                        try {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/22657544635")))
                        } catch (_: Exception) { toast("WhatsApp indisponible") }
                    }) { Text("WhatsApp", fontWeight = FontWeight.Bold) }
                },
                dismissButton = { TextButton(onClick = { showAbout = false }) { Text("Fermer") } }
            )
        }
        if (showPicker) {
            ServerPicker(
                servers = all, selectedId = selected?.id, nowMs = nowMs,
                onPick = { selectedId = it.id; VpnState.error.value = null; showPicker = false },
                onDismiss = { showPicker = false }
            )
        }
        if (showFiles) {
            AlertDialog(
                onDismissRequest = { showFiles = false },
                title = { Text("Fichiers ZONGO Digital") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { showFiles = false; importLauncher.launch(arrayOf("*/*")) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Importer un fichier") }
                        Button(
                            onClick = { showFiles = false; showPaste = true },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Coller un code zongodigital://") }
                        Button(
                            enabled = exportable.isNotEmpty(),
                            onClick = {
                                showFiles = false
                                exportMode = "file"; showExpiry = true
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)
                        ) { Text("Exporter mes serveurs (fichier)") }
                        Button(
                            enabled = exportable.isNotEmpty(),
                            onClick = {
                                showFiles = false
                                exportMode = "share"; showExpiry = true
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)
                        ) { Text("Partager (texte)") }
                        if (exportable.isEmpty()) {
                            Text("Ajoute d'abord un serveur pour pouvoir l'exporter.", color = Muted, fontSize = 12.sp)
                        }
                    }
                },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { showFiles = false }) { Text("Fermer") } }
            )
        }
        if (showExpiry) {
            var days by remember { mutableStateOf("30") }
            AlertDialog(
                onDismissRequest = { showExpiry = false },
                title = { Text("Validité du fichier") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Après cette durée, le fichier ne marchera plus pour tes utilisateurs.", color = Muted, fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("7", "30", "90").forEach { d ->
                                OutlinedButton(onClick = { days = d }, contentPadding = PaddingValues(horizontal = 12.dp)) {
                                    Text("$d j")
                                }
                            }
                        }
                        OutlinedTextField(
                            days, { days = it.filter { c -> c.isDigit() }.take(4) },
                            label = { Text("Durée en jours (vide = sans limite)") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                        val n = days.toIntOrNull() ?: 0
                        if (n > 0) {
                            Text(
                                "Expire le " + Expiry.format(Expiry.now(ctx) + n * 86_400_000L),
                                color = Gold, fontSize = 13.sp
                            )
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val n = days.toIntOrNull() ?: 0
                        exportExp = if (n > 0) Expiry.now(ctx) + n * 86_400_000L else 0L
                        showExpiry = false
                        if (exportMode == "file") {
                            exportLauncher.launch("zongodigital-serveurs.${ZongoCodec.EXTENSION}")
                        } else {
                            val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                                .putExtra(Intent.EXTRA_TEXT, ZongoCodec.export(exportable, exportExp))
                            ctx.startActivity(Intent.createChooser(send, "Partager"))
                        }
                    }) { Text("Continuer") }
                },
                dismissButton = { TextButton(onClick = { showExpiry = false }) { Text("Annuler") } }
            )
        }
        if (showPaste) {
            var code by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { showPaste = false },
                title = { Text("Coller un code") },
                text = {
                    OutlinedTextField(
                        code, { code = it }, label = { Text("zongodigital://…") }, maxLines = 6,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        val (ok, msg) = addImported(code)
                        toast(msg)
                        if (ok) showPaste = false
                    }) { Text("Importer") }
                },
                dismissButton = { TextButton(onClick = { showPaste = false }) { Text("Annuler") } }
            )
        }
        if (showSsh) {
            AddProfileDialog(
                onDismiss = { showSsh = false },
                onSave = { p ->
                    profiles = (profiles + p).also(store::save)
                    selectedId = p.id
                    showSsh = false
                }
            )
        }
        if (showV2) {
            V2Editor(
                initial = v2Edit,
                presetProtocol = v2Preset,
                onDismiss = { showV2 = false },
                onSave = { p ->
                    val updated =
                        if (profiles.any { it.id == p.id }) profiles.map { if (it.id == p.id) p else it }
                        else profiles + p
                    profiles = updated
                    store.save(updated)
                    selectedId = p.id
                    showV2 = false
                }
            )
        }
        if (showLog) LogDialog { showLog = false }
    }
}

/** « Choisir un serveur » : liste avec ping (temps de réponse) et choix automatique. */
@Composable
fun ServerPicker(
    servers: List<Profile>, selectedId: String?, nowMs: Long, onPick: (Profile) -> Unit, onDismiss: () -> Unit
) {
    val pings = remember { mutableStateMapOf<String, Int>() } // -1 = ne répond pas
    LaunchedEffect(servers) {
        servers.filter { !Expiry.isExpired(it, nowMs) }.forEach { s -> launch { pings[s.id] = Ping.ms(s) ?: -1 } }
    }
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Color(0xFF0B1E3F))
                .border(2.dp, Blue, RoundedCornerShape(28.dp)).padding(20.dp)
        ) {
            Text("Choisir un serveur", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(14.dp))
            Column(
                Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0xFF10254B))
                        .clickable {
                            val valid = servers.filter { !Expiry.isExpired(it, nowMs) }
                            val best = valid.filter { (pings[it.id] ?: -1) >= 0 }
                                .minByOrNull { pings[it.id] ?: Int.MAX_VALUE } ?: valid.firstOrNull()
                            best?.let(onPick)
                        }
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) { Text("⚡ Auto (meilleur ping)", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }

                if (servers.isEmpty()) {
                    Text(
                        "Aucun serveur. Ferme cette fenêtre puis appuie sur « + Ajouter ».",
                        color = Muted, fontSize = 14.sp, modifier = Modifier.padding(8.dp)
                    )
                }
                servers.forEach { s ->
                    val ping = pings[s.id]
                    val expired = Expiry.isExpired(s, nowMs)
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                            .background(if (s.id == selectedId) Color(0xFF0F5F46) else Color(0xFF10254B))
                            .clickable(enabled = !expired) { onPick(s) }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            s.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, modifier = Modifier.weight(1f)
                        )
                        Text(
                            when {
                                expired -> "Expiré"
                                ping == null -> "…"
                                ping < 0 -> "—"
                                else -> "$ping ms"
                            },
                            color = when {
                                expired -> Color(0xFFFF5C6C)
                                ping == null -> Muted
                                ping < 0 -> Color(0xFFFF5C6C)
                                else -> Green
                            },
                            fontSize = 15.sp, fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PlusItem(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(16.dp)).background(CardBg)
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, fontSize = 22.sp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        Text("▸", color = Muted)
    }
}

@Composable
fun MenuRow(label: String, arrow: Boolean = false, muted: Boolean = false, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(label, fontSize = 16.sp, color = if (muted) Muted else Color.White) },
        trailingIcon = { if (arrow) Text("▸", color = Muted) },
        onClick = onClick
    )
}

@Composable
fun StatTile(title: String, value: String, color: Color, modifier: Modifier = Modifier, sub: String? = null) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xFF0F1E3F)).padding(14.dp)
    ) {
        Text(title, color = color, fontSize = 11.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(4.dp))
        Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        if (sub != null) {
            Spacer(Modifier.height(2.dp))
            Text(sub, color = color, fontSize = 12.sp)
        }
    }
}

/** Gros bouton rond avec halo qui pulse, compte à rebours ou icône marche/arrêt. */
@Composable
fun PowerButton(color: Color, pulse: Boolean, centerText: String?, onClick: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val scale by transition.animateFloat(
        initialValue = 0.9f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "scale"
    )
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(200.dp)) {
        Box(
            Modifier.fillMaxSize().scale(if (pulse) scale else 1f).background(
                Brush.radialGradient(listOf(color.copy(alpha = 0.40f), Color.Transparent)), CircleShape
            )
        )
        Box(
            Modifier.size(146.dp).clip(CircleShape)
                .background(Brush.verticalGradient(listOf(Color(0xFF0C1B3D), Color(0xFF050E22))))
                .border(5.dp, color, CircleShape).clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            if (centerText != null) {
                Text(centerText, color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Light)
            } else {
                Canvas(Modifier.size(60.dp)) {
                    val w = size.width
                    val stroke = w * 0.1f
                    drawArc(
                        color = Color.White, startAngle = -60f, sweepAngle = 300f, useCenter = false,
                        topLeft = Offset(w * 0.1f, w * 0.16f), size = Size(w * 0.8f, w * 0.8f),
                        style = Stroke(width = stroke, cap = StrokeCap.Round)
                    )
                    drawLine(
                        Color.White, Offset(w / 2, w * 0.04f), Offset(w / 2, w * 0.5f),
                        strokeWidth = stroke, cap = StrokeCap.Round
                    )
                }
            }
        }
    }
}

/** Logo : fond bleu nuit, lettre Z dorée (même dessin que l'icône de l'application). */
@Composable
fun LogoMark(modifier: Modifier = Modifier) {
    Canvas(modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFF0B1F4A))) {
        val w = size.width
        val h = size.height
        fun px(x: Float) = w * (0.2f + 0.6f * (x - 34f) / 40f)
        fun py(y: Float) = h * (0.22f + 0.56f * (y - 36f) / 38f)
        val z = Path().apply {
            moveTo(px(34f), py(36f)); lineTo(px(74f), py(36f)); lineTo(px(74f), py(44f))
            lineTo(px(48f), py(66f)); lineTo(px(74f), py(66f)); lineTo(px(74f), py(74f))
            lineTo(px(34f), py(74f)); lineTo(px(34f), py(66f)); lineTo(px(60f), py(44f))
            lineTo(px(34f), py(44f)); close()
        }
        drawPath(z, Gold)
    }
}

@Composable
fun LogDialog(onDismiss: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    val text = remember { AppLog.tail() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Journal") },
        text = {
            Box(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                Text(
                    text.ifBlank { "(vide) Lance une connexion puis rouvre le journal." },
                    fontFamily = FontFamily.Monospace, fontSize = 10.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { clipboard.setText(AnnotatedString(text)) }) { Text("Copier") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}

@Composable
fun AddProfileDialog(onDismiss: () -> Unit, onSave: (Profile) -> Unit) {
    var type by remember { mutableStateOf(ProfileType.SSH) }
    var name by remember { mutableStateOf("") }
    var host by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("22") }
    var user by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nouveau serveur SSH") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true)
                if (type == ProfileType.SSH) {
                    OutlinedTextField(host, { host = it }, label = { Text("Serveur") }, singleLine = true)
                    OutlinedTextField(port, { port = it }, label = { Text("Port") }, singleLine = true)
                    OutlinedTextField(user, { user = it }, label = { Text("Utilisateur") }, singleLine = true)
                    OutlinedTextField(
                        password, { password = it }, label = { Text("Mot de passe") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation()
                    )
                } else {
                    OutlinedTextField(link, { link = it }, label = { Text("Lien vmess:// vless:// trojan:// …") })
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = {
                    onSave(
                        Profile(
                            name = name.trim(), type = type,
                            host = host.trim(), port = port.toIntOrNull() ?: 22,
                            user = user.trim(), password = password, link = link.trim()
                        )
                    )
                }
            ) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}
