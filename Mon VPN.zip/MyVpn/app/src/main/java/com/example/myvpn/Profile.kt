package com.example.myvpn

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class ProfileType { SSH, V2RAY }

data class Profile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: ProfileType,
    // SSH
    val host: String = "",
    val port: Int = 22,
    val user: String = "",
    val password: String = "",
    val hostKeyFingerprint: String = "", // vide = accepte toute clé (à éviter en production)
    // V2Ray : lien vmess:// vless:// trojan:// ou JSON de config complet
    val link: String = "",
) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("name", name); put("type", type.name)
        put("host", host); put("port", port); put("user", user)
        put("password", password); put("hostKeyFingerprint", hostKeyFingerprint)
        put("link", link)
    }

    companion object {
        fun fromJson(o: JSONObject) = Profile(
            id = o.getString("id"),
            name = o.getString("name"),
            type = ProfileType.valueOf(o.getString("type")),
            host = o.optString("host"),
            port = o.optInt("port", 22),
            user = o.optString("user"),
            password = o.optString("password"),
            hostKeyFingerprint = o.optString("hostKeyFingerprint"),
            link = o.optString("link"),
        )
    }
}

/** Stockage simple. TODO : passer à EncryptedSharedPreferences pour les mots de passe. */
class ProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("profiles", Context.MODE_PRIVATE)

    fun load(): List<Profile> {
        val arr = JSONArray(prefs.getString("list", "[]"))
        return (0 until arr.length()).map { Profile.fromJson(arr.getJSONObject(it)) }
    }

    fun save(list: List<Profile>) {
        val arr = JSONArray().also { a -> list.forEach { a.put(it.toJson()) } }
        prefs.edit().putString("list", arr.toString()).apply()
    }
}
