package com.example.myvpn

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class ProfileType { SSH, V2RAY }

data class Profile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: ProfileType,
    // SSH
    val host: String = "",
    val port: Int = 22,
    val user: String = "",
    val password: String = "",
    val hostKeyFingerprint: String = "", // vide = accepte toute clé (à éviter en production)
    // V2Ray : lien vmess:// vless:// trojan:// ou JSON de config complet
    val link: String = "",
    // Serveur protégé (importé d'un fichier ou officiel) : détails cachés, non modifiable
    val locked: Boolean = false,
    // Date d'expiration (millisecondes) ; 0 = sans limite
    val expiresAt: Long = 0L,
) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("name", name); put("type", type.name)
        put("host", host); put("port", port); put("user", user)
        put("password", password); put("hostKeyFingerprint", hostKeyFingerprint)
        put("link", link); put("locked", locked); put("expiresAt", expiresAt)
    }

    companion object {
        fun fromJson(o: JSONObject) = Profile(
            id = o.getString("id"),
            name = o.getString("name"),
            type = ProfileType.valueOf(o.getString("type")),
            host = o.optString("host"),
            port = o.optInt("port", 22),
            user = o.optString("user"),
            password = o.optString("password"),
            hostKeyFingerprint = o.optString("hostKeyFingerprint"),
            link = o.optString("link"),
            locked = o.optBoolean("locked", false),
            expiresAt = o.optLong("expiresAt", 0L),
        )
    }
}

/** Stockage simple. TODO : passer à EncryptedSharedPreferences pour les mots de passe. */
class ProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("profiles", Context.MODE_PRIVATE)

    fun load(): List<Profile> {
        val arr = JSONArray(prefs.getString("list", "[]"))
        return (0 until arr.length()).map { Profile.fromJson(arr.getJSONObject(it)) }
    }

    fun save(list: List<Profile>) {
        val arr = JSONArray().also { a -> list.forEach { a.put(it.toJson()) } }
        prefs.edit().putString("list", arr.toString()).apply()
    }
}

/** Dates d'expiration. L'heure utilisée ne recule jamais (changer l'heure du téléphone ne sert à rien). */
object Expiry {
    fun now(ctx: Context): Long {
        val prefs = ctx.getSharedPreferences("clock", Context.MODE_PRIVATE)
        val n = maxOf(System.currentTimeMillis(), prefs.getLong("last", 0L))
        prefs.edit().putLong("last", n).apply()
        return n
    }

    fun isExpired(p: Profile, now: Long) = p.expiresAt > 0 && now > p.expiresAt

    fun format(ms: Long): String =
        java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.FRANCE).format(java.util.Date(ms))

    const val MESSAGE = "Ton fichier a expiré — appuie sur « + Ajouter » pour en importer un nouveau"
}
