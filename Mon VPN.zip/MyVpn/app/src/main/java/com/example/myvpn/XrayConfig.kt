package com.example.myvpn

import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

/** Construit la configuration JSON de Xray à partir d'un profil. */
object XrayConfig {

    /** Profil SSH : tout le trafic du TUN part vers le SOCKS local du tunnel SSH. */
    fun forSocks(port: Int): String {
        val proxy = JSONObject()
            .put("tag", "proxy")
            .put("protocol", "socks")
            .put(
                "settings", JSONObject().put(
                    "servers", JSONArray().put(
                        JSONObject().put("address", "127.0.0.1").put("port", port)
                    )
                )
            )
        // SSH ne transporte pas l'UDP : les requêtes DNS sont refaites en TCP via le tunnel
        val dnsOut = JSONObject().put("tag", "dns-out").put("protocol", "dns")
        val config = base(JSONArray().put(proxy).put(dnsOut))
        config.put(
            "dns", JSONObject().put("servers", JSONArray().put("tcp://1.1.1.1").put("tcp://8.8.8.8"))
        )
        config.put(
            "routing", JSONObject()
                .put("domainStrategy", "AsIs")
                .put(
                    "rules", JSONArray().put(
                        JSONObject()
                            .put("type", "field")
                            .put("inboundTag", JSONArray().put("tun-in"))
                            .put("port", "53")
                            .put("outboundTag", "dns-out")
                    )
                )
        )
        return config.toString()
    }

    /** Profil V2Ray : lien vmess:// vless:// trojan:// ou JSON complet. */
    fun fromLink(link: String): String {
        val l = link.trim()
        require(l.isNotEmpty()) { "Lien V2Ray vide" }
        return when {
            l.startsWith("{") -> {
                val o = JSONObject(l)
                o.put("inbounds", JSONArray().put(tunInbound()))
                o.put("log", logConfig())
                o.toString()
            }
            l.startsWith("vmess://") -> base(JSONArray().put(vmess(l))).toString()
            l.startsWith("vless://") -> base(JSONArray().put(vless(l))).toString()
            l.startsWith("trojan://") -> base(JSONArray().put(trojan(l))).toString()
            else -> throw IllegalArgumentException("Lien non géré (vmess://, vless://, trojan:// ou JSON)")
        }
    }

    // ---------- éléments communs ----------

    /** Xray écrit son journal dans le même fichier que l'application (bouton « Journal »). */
    private fun logConfig() = JSONObject().put("loglevel", "info").apply {
        AppLog.path()?.let { put("access", it); put("error", it) }
    }

    private fun tunInbound() = JSONObject()
        .put("tag", "tun-in")
        .put("protocol", "tun")
        .put("settings", JSONObject().put("name", "xray0").put("mtu", 1500).put("userLevel", 0))
        .put(
            "sniffing", JSONObject()
                .put("enabled", true)
                .put("destOverride", JSONArray().put("http").put("tls"))
        )

    private fun base(outbounds: JSONArray) = JSONObject()
        .put("log", logConfig())
        .put("inbounds", JSONArray().put(tunInbound()))
        .put("outbounds", outbounds)

    private fun stream(
        net: String, security: String, host: String, path: String,
        sni: String, fp: String, alpn: String,
        pbk: String = "", sid: String = "", spx: String = "",
        headerType: String = "none", insecure: Boolean = false
    ): JSONObject {
        val n = if (net.isBlank()) "tcp" else net
        val s = JSONObject().put("network", n)
        when (n) {
            "ws" -> s.put(
                "wsSettings", JSONObject().put("path", path.ifBlank { "/" })
                    .put("headers", JSONObject().put("Host", host))
            )
            "grpc" -> s.put(
                "grpcSettings", JSONObject().put("serviceName", path).apply {
                    if (host.isNotBlank()) put("authority", host)
                    if (headerType == "multi") put("multiMode", true)
                }
            )
            "tcp" -> if (headerType == "http") s.put(
                "tcpSettings", JSONObject().put(
                    "header", JSONObject().put("type", "http").put(
                        "request", JSONObject()
                            .put("path", JSONArray().put(path.ifBlank { "/" }))
                            .put("headers", JSONObject().put("Host", JSONArray().put(host)))
                    )
                )
            )
            "httpupgrade" -> s.put(
                "httpupgradeSettings", JSONObject().put("path", path.ifBlank { "/" }).put("host", host)
            )
            "xhttp", "splithttp" -> s.put(
                "xhttpSettings", JSONObject().put("path", path.ifBlank { "/" }).put("host", host)
            )
        }
        when (security) {
            "tls" -> {
                val t = JSONObject().put("serverName", sni.ifBlank { host })
                if (fp.isNotBlank()) t.put("fingerprint", fp)
                if (alpn.isNotBlank()) t.put("alpn", JSONArray(alpn.split(",")))
                s.put("security", "tls").put("tlsSettings", t)
            }
            "reality" -> s.put("security", "reality").put(
                "realitySettings", JSONObject()
                    .put("serverName", sni).put("fingerprint", fp.ifBlank { "chrome" })
                    .put("publicKey", pbk).put("shortId", sid).put("spiderX", spx)
            )
            else -> s.put("security", "none")
        }
        return s
    }

    // ---------- protocoles ----------

    private fun vmess(link: String): JSONObject {
        var b64 = link.removePrefix("vmess://").trim().replace('-', '+').replace('_', '/')
        while (b64.length % 4 != 0) b64 += "="
        val j = JSONObject(String(Base64.decode(b64, Base64.DEFAULT)))
        val host = j.optString("host")
        val sec = if (j.optString("tls") == "tls") "tls" else "none"
        return JSONObject()
            .put("tag", "proxy").put("protocol", "vmess")
            .put(
                "settings", JSONObject().put(
                    "vnext", JSONArray().put(
                        JSONObject()
                            .put("address", j.getString("add"))
                            .put("port", j.optInt("port", 443))
                            .put(
                                "users", JSONArray().put(
                                    JSONObject()
                                        .put("id", j.getString("id"))
                                        .put("alterId", j.optInt("aid", 0))
                                        .put("security", j.optString("scy").ifBlank { "auto" })
                                )
                            )
                    )
                )
            )
            .put(
                "streamSettings", stream(
                    j.optString("net"), sec, host, j.optString("path"),
                    j.optString("sni"), j.optString("fp"), j.optString("alpn"),
                    headerType = j.optString("type"),
                    insecure = j.optString("allowInsecure") in listOf("1", "true")
                )
            )
    }

    private fun vless(link: String): JSONObject {
        val u = Uri.parse(link)
        fun q(k: String) = u.getQueryParameter(k) ?: ""
        val addr = u.host ?: throw IllegalArgumentException("Lien vless invalide")
        val user = JSONObject().put("id", u.userInfo ?: "").put("encryption", q("encryption").ifBlank { "none" })
        if (q("flow").isNotBlank()) user.put("flow", q("flow"))
        return JSONObject()
            .put("tag", "proxy").put("protocol", "vless")
            .put(
                "settings", JSONObject().put(
                    "vnext", JSONArray().put(
                        JSONObject().put("address", addr).put("port", if (u.port > 0) u.port else 443)
                            .put("users", JSONArray().put(user))
                    )
                )
            )
            .put(
                "streamSettings", stream(
                    q("type"), q("security"), q("host").ifBlank { addr }, q("path").ifBlank { q("serviceName") },
                    q("sni"), q("fp"), q("alpn"), q("pbk"), q("sid"), q("spx"),
                    q("headerType"), q("allowInsecure") == "1" || q("insecure") == "1"
                )
            )
    }

    private fun trojan(link: String): JSONObject {
        val u = Uri.parse(link)
        fun q(k: String) = u.getQueryParameter(k) ?: ""
        val addr = u.host ?: throw IllegalArgumentException("Lien trojan invalide")
        val sec = q("security").ifBlank { "tls" }
        return JSONObject()
            .put("tag", "proxy").put("protocol", "trojan")
            .put(
                "settings", JSONObject().put(
                    "servers", JSONArray().put(
                        JSONObject().put("address", addr).put("port", if (u.port > 0) u.port else 443)
                            .put("password", u.userInfo ?: "")
                    )
                )
            )
            .put(
                "streamSettings", stream(
                    q("type"), sec, q("host").ifBlank { addr }, q("path").ifBlank { q("serviceName") },
                    q("sni"), q("fp"), q("alpn")
                )
            )
    }
}
