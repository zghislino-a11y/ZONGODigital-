package com.example.myvpn

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import org.json.JSONObject
import kotlin.concurrent.thread

class MyVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private var ssh: SshEngine? = null
    @Volatile private var generation = 0          // change à chaque arrêt : permet d'annuler une connexion en cours
    @Volatile private var watchdog: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        AppLog.init(applicationContext)
        when (intent?.action) {
            ACTION_STOP -> { AppLog.add("Déconnexion demandée"); stopVpn(); stopSelf() }
            else -> {
                val json = intent?.getStringExtra(EXTRA_PROFILE) ?: return START_NOT_STICKY
                val profile = Profile.fromJson(JSONObject(json))
                thread(name = "vpn-start") { startVpn(profile) }
            }
        }
        return START_NOT_STICKY
    }

    private fun startVpn(profile: Profile, reconnect: Boolean = false) {
        var gen = -1
        try {
            stopVpn()
            gen = ++generation
            if (!reconnect) AppLog.reset()
            VpnState.error.value = null
            VpnState.connecting.value = true
            AppLog.add((if (reconnect) "Reconnexion à « " else "Connexion à « ") + "${profile.name} » (${profile.type})")

            // 0. Le serveur répond-il ? (avant de toucher au réseau du téléphone)
            AppLog.add("Vérification du serveur…")
            Probe.reachable(profile)?.let { error(it) }
            if (gen != generation) return

            // 1. Prépare la configuration du cœur Xray selon le type de profil
            val config = when (profile.type) {
                ProfileType.SSH -> {
                    val e = SshEngine()
                    e.start(profile, SOCKS_PORT) // ouvre le tunnel SSH + SOCKS local
                    ssh = e
                    AppLog.add("Tunnel SSH ouvert")
                    XrayConfig.forSocks(SOCKS_PORT)
                }
                ProfileType.V2RAY -> XrayConfig.fromLink(profile.link)
            }
            AppLog.add("Configuration Xray prête (${config.length} caractères)")

            // 2. Crée l'interface VPN (TUN)
            val iface = Builder()
                .setSession(profile.name)
                .addAddress("10.0.0.2", 32)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("1.1.1.1")
                .addDnsServer("8.8.8.8")
                .setMtu(1400)
                // Évite la boucle : le trafic de l'app elle-même (SSH, V2Ray) sort hors VPN
                .addDisallowedApplication(packageName)
                .establish() ?: error("Permission VPN refusée")
            tun = iface
            AppLog.add("Interface VPN créée (fd=${iface.fd})")

            // 3. Démarre Xray sur le TUN
            XrayCore.start(this, config, iface.fd)
            AppLog.add("Xray démarré")

            // 4. Vrai test de bout en bout : on n'affiche « Connecté » que si Internet répond via le serveur
            AppLog.add("Test de la connexion…")
            var ok = false
            for (i in 1..3) {
                if (gen != generation) return
                if (Probe.viaProxy()) { ok = true; break }
                AppLog.add("Pas de réponse (essai $i/3)")
                Thread.sleep(1500)
            }
            if (gen != generation) return
            if (!ok) error("Le serveur ne laisse pas passer Internet : vérifie l'uuid ou le mot de passe, le path et le SNI")
            AppLog.add("Connexion vérifiée ✓")
            VpnState.connected.value = profile.id
            startWatchdog(profile, gen)
        } catch (t: Throwable) {
            Log.e(TAG, "Échec de connexion", t)
            AppLog.add("ERREUR : ${t.message ?: t.javaClass.simpleName}")
            VpnState.error.value = t.message ?: t.javaClass.simpleName
            stopVpn()
            stopSelf()
        } finally {
            VpnState.connecting.value = false
        }
    }

    /** Surveille la connexion toutes les 20 s et se reconnecte toute seule si elle est perdue. */
    private fun startWatchdog(profile: Profile, gen: Int) {
        val t = thread(name = "vpn-watchdog") {
            var fails = 0
            try {
                while (gen == generation && VpnState.connected.value == profile.id) {
                    Thread.sleep(20_000)
                    if (gen != generation) return@thread
                    if (Probe.viaProxy()) {
                        fails = 0
                    } else {
                        fails++
                        AppLog.add("Connexion instable ($fails/2)")
                        if (fails >= 2) {
                            AppLog.add("Connexion perdue — reconnexion automatique…")
                            startVpn(profile, reconnect = true)
                            return@thread
                        }
                    }
                }
            } catch (_: InterruptedException) {
            }
        }
        watchdog = t
    }

    private fun stopVpn() {
        generation++
        val w = watchdog
        if (w != null && w !== Thread.currentThread()) w.interrupt()
        watchdog = null
        XrayCore.stop()
        ssh?.stop(); ssh = null
        try { tun?.close() } catch (_: Throwable) {}
        tun = null
        VpnState.connected.value = null
        VpnState.connecting.value = false
    }

    override fun onRevoke() { stopVpn(); super.onRevoke() }
    override fun onDestroy() { stopVpn(); super.onDestroy() }

    companion object {
        const val ACTION_START = "com.example.myvpn.START"
        const val ACTION_STOP = "com.example.myvpn.STOP"
        const val EXTRA_PROFILE = "profile"
        const val SOCKS_PORT = 10808
        private const val TAG = "MyVpnService"
    }
}
