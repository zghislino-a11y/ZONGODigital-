package com.example.myvpn

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import org.json.JSONObject
import kotlin.concurrent.thread

class MyVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private var ssh: SshEngine? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopVpn(); stopSelf() }
            else -> {
                val json = intent?.getStringExtra(EXTRA_PROFILE) ?: return START_NOT_STICKY
                val profile = Profile.fromJson(JSONObject(json))
                thread(name = "vpn-start") { startVpn(profile) }
            }
        }
        return START_NOT_STICKY
    }

    private fun startVpn(profile: Profile) {
        try {
            stopVpn()
            VpnState.error.value = null

            // 1. Prépare la configuration du cœur Xray selon le type de profil
            val config = when (profile.type) {
                ProfileType.SSH -> {
                    val e = SshEngine()
                    e.start(profile, SOCKS_PORT) // ouvre le tunnel SSH + SOCKS local
                    ssh = e
                    XrayConfig.forSocks(SOCKS_PORT)
                }
                ProfileType.V2RAY -> XrayConfig.fromLink(profile.link)
            }

            // 2. Crée l'interface VPN (TUN)
            val iface = Builder()
                .setSession(profile.name)
                .addAddress("10.0.0.2", 32)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("1.1.1.1")
                .setMtu(1500)
                // Évite la boucle : le trafic de l'app elle-même (SSH, V2Ray) sort hors VPN
                .addDisallowedApplication(packageName)
                .establish() ?: error("Permission VPN refusée")
            tun = iface

            // 3. Démarre Xray sur le TUN
            XrayCore.start(this, config, iface.fd)
            VpnState.connected.value = profile.id
        } catch (t: Throwable) {
            Log.e(TAG, "Échec de connexion", t)
            VpnState.error.value = t.message ?: t.javaClass.simpleName
            stopVpn()
            stopSelf()
        }
    }

    private fun stopVpn() {
        XrayCore.stop()
        ssh?.stop(); ssh = null
        try { tun?.close() } catch (_: Throwable) {}
        tun = null
        VpnState.connected.value = null
    }

    override fun onRevoke() { stopVpn(); super.onRevoke() }
    override fun onDestroy() { stopVpn(); super.onDestroy() }

    companion object {
        const val ACTION_START = "com.example.myvpn.START"
        const val ACTION_STOP = "com.example.myvpn.STOP"
        const val EXTRA_PROFILE = "profile"
        const val SOCKS_PORT = 10808
        private const val TAG = "MyVpnService"
    }
}
