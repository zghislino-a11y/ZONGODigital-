package com.example.myvpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import kotlin.concurrent.thread

class MyVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private var ssh: SshEngine? = null
    @Volatile private var generation = 0          // change à chaque arrêt : permet d'annuler une connexion en cours
    @Volatile private var watchdog: Thread? = null
    @Volatile private var netChanged = false
    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private var current: Profile? = null
    private var alternatives: List<Profile> = emptyList()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        AppLog.init(applicationContext)
        when (intent?.action) {
            ACTION_STOP -> { AppLog.add("Déconnexion demandée"); stopVpn(); stopSelf() }
            else -> {
                val json = intent?.getStringExtra(EXTRA_PROFILE) ?: return START_NOT_STICKY
                val profile = Profile.fromJson(JSONObject(json))
                val fallbacks = try {
                    val arr = JSONArray(intent.getStringExtra(EXTRA_FALLBACKS) ?: "[]")
                    (0 until arr.length()).map { Profile.fromJson(JSONObject(arr.getString(it))) }
                } catch (_: Exception) { emptyList() }
                thread(name = "vpn-start") { startVpn(profile, fallbacks) }
            }
        }
        return START_NOT_STICKY
    }

    /** Essaie le serveur choisi ; s'il échoue, essaie automatiquement les suivants (basculement). */
    private fun startVpn(primary: Profile, fallbacks: List<Profile>, reconnect: Boolean = false) {
        try {
            stopVpn()
            val gen = ++generation
            if (!reconnect) AppLog.reset()
            VpnState.error.value = null
            VpnState.connecting.value = true
            showNotification("Connexion en cours…")
            val all = listOf(primary) + fallbacks
            var lastError = "Connexion impossible"
            for ((i, p) in all.withIndex()) {
                if (gen != generation) return
                if (i > 0) AppLog.add("Basculement automatique vers « ${p.name} »")
                try {
                    val hasMore = i < all.size - 1
                    if (connectOnce(p, gen, reconnect && i == 0, hasMore)) {
                        current = p
                        alternatives = all.filter { it.id != p.id }
                        showNotification("Connecté : ${p.name}")
                    }
                    return
                } catch (t: Throwable) {
                    if (gen != generation) return
                    Log.e(TAG, "Échec de connexion", t)
                    lastError = t.message ?: t.javaClass.simpleName
                    AppLog.add("ERREUR : $lastError")
                    releaseResources()
                }
            }
            VpnState.error.value = lastError
            stopVpn()
            stopSelf()
        } catch (t: Throwable) {
            Log.e(TAG, "Échec de connexion", t)
            VpnState.error.value = t.message ?: t.javaClass.simpleName
            stopVpn()
            stopSelf()
        } finally {
            VpnState.connecting.value = false
        }
    }

    /** Une tentative de connexion. Retourne true si connecté, false si annulée ; lève une erreur sinon. */
    private fun connectOnce(profile: Profile, gen: Int, reconnect: Boolean, hasMore: Boolean): Boolean {
        AppLog.add((if (reconnect) "Reconnexion à « " else "Connexion à « ") + "${profile.name} » (${profile.type})")

        // 0. Le serveur répond-il ? (avant de toucher au réseau du téléphone)
        AppLog.add("Vérification du serveur…")
        Probe.reachable(profile)?.let { error(it) }
        if (gen != generation) return false

        // 1. Prépare la configuration du cœur Xray selon le type de profil
        val config = when (profile.type) {
            ProfileType.SSH -> {
                val e = SshEngine()
                e.start(profile, SOCKS_PORT) // ouvre le tunnel SSH + SOCKS local
                ssh = e
                AppLog.add("Tunnel SSH ouvert")
                XrayConfig.forSocks(SOCKS_PORT)
            }
            ProfileType.V2RAY -> XrayConfig.fromLink(profile.link)
        }
        AppLog.add("Configuration Xray prête (${config.length} caractères)")

        // 2. Crée l'interface VPN (TUN)
        val iface = Builder()
            .setSession(profile.name)
            .addAddress("10.0.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .addDnsServer("8.8.8.8")
            .setMtu(1400)
            // Évite la boucle : le trafic de l'app elle-même (SSH, V2Ray) sort hors VPN
            .addDisallowedApplication(packageName)
            .establish() ?: error("Permission VPN refusée")
        tun = iface
        AppLog.add("Interface VPN créée (fd=${iface.fd})")

        // 3. Démarre Xray sur le TUN
        XrayCore.start(this, config, iface.fd)
        AppLog.add("Xray démarré")

        // 4. Vrai test de bout en bout
        AppLog.add("Test de la connexion…")
        var ok = false
        for (i in 1..2) {
            if (gen != generation) return false
            if (Probe.viaProxy()) { ok = true; break }
            AppLog.add("Pas de réponse (essai $i/2)")
            Thread.sleep(1500)
        }
        if (gen != generation) return false
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val strict = prefs.getBoolean("strict", false)
        // S'il reste un autre serveur à essayer, on ne garde pas un serveur qui ne laisse pas passer Internet
        if (!ok && (strict || hasMore)) {
            error("Le serveur ne laisse pas passer Internet : vérifie l'uuid ou le mot de passe, le path et le SNI")
        }
        if (ok) AppLog.add("Connexion vérifiée ✓")
        else AppLog.add("Test non concluant — connexion maintenue (mode souple)")
        VpnState.connected.value = profile.id
        if (ok) {
            registerNetCallback()
            startWatchdog(profile, gen)
        }
        return true
    }

    /** Surveille la connexion (toutes les 15 s, et tout de suite après un changement de réseau) et se reconnecte seule. */
    private fun startWatchdog(profile: Profile, gen: Int) {
        val t = thread(name = "vpn-watchdog") {
            var fails = 0
            var waited = 0
            try {
                while (gen == generation && VpnState.connected.value == profile.id) {
                    Thread.sleep(1000)
                    waited++
                    if (gen != generation) return@thread
                    val changed = netChanged
                    if (!changed && waited < 15) continue
                    if (changed) {
                        netChanged = false
                        AppLog.add("Changement de réseau détecté")
                        Thread.sleep(2000)
                    }
                    waited = 0
                    if (Probe.viaProxy()) {
                        fails = 0
                    } else {
                        fails++
                        AppLog.add("Connexion instable ($fails/2)")
                        if (fails >= 2 || changed) {
                            AppLog.add("Connexion perdue — reconnexion automatique…")
                            val prefs = getSharedPreferences("settings", MODE_PRIVATE)
                            val fb = if (prefs.getBoolean("failover", true)) alternatives else emptyList()
                            startVpn(profile, fb, reconnect = true)
                            return@thread
                        }
                    }
                }
            } catch (_: InterruptedException) {
            }
        }
        watchdog = t
    }

    /** Prévient quand le téléphone change de réseau (Wi-Fi ↔ 4G) pour réagir immédiatement. */
    private fun registerNetCallback() {
        unregisterNetCallback()
        try {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            var first = true
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { if (first) first = false else netChanged = true }
                override fun onLost(network: Network) { netChanged = true }
            }
            cm.registerDefaultNetworkCallback(cb)
            netCallback = cb
        } catch (_: Exception) {
        }
    }

    private fun unregisterNetCallback() {
        try {
            val cb = netCallback
            if (cb != null) (getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(cb)
        } catch (_: Exception) {
        }
        netCallback = null
        netChanged = false
    }

    /** Notification permanente : empêche Android de couper le VPN en arrière-plan. */
    private fun showNotification(text: String) {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "Connexion VPN", NotificationManager.IMPORTANCE_LOW)
                )
            }
            val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
            val stop = PendingIntent.getService(
                this, 1, Intent(this, MyVpnService::class.java).setAction(ACTION_STOP), flags
            )
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
            @Suppress("DEPRECATION")
            val n = b.setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle("ZONGO Digital")
                .setContentText(text)
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Déconnecter", stop)
                .build()
            if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, 1024) // systemExempted
            else startForeground(NOTIF_ID, n)
        } catch (t: Throwable) {
            Log.w(TAG, "Notification impossible", t)
        }
    }

    /** Libère le tunnel et Xray sans changer l'état affiché (utile entre deux tentatives). */
    private fun releaseResources() {
        XrayCore.stop()
        ssh?.stop(); ssh = null
        try { tun?.close() } catch (_: Throwable) {}
        tun = null
    }

    private fun stopVpn() {
        generation++
        val w = watchdog
        if (w != null && w !== Thread.currentThread()) w.interrupt()
        watchdog = null
        unregisterNetCallback()
        releaseResources()
        VpnState.connected.value = null
        VpnState.connecting.value = false
        try { stopForeground(true) } catch (_: Throwable) {}
    }

    override fun onRevoke() { stopVpn(); super.onRevoke() }
    override fun onDestroy() { stopVpn(); super.onDestroy() }

    companion object {
        const val ACTION_START = "com.example.myvpn.START"
        const val ACTION_STOP = "com.example.myvpn.STOP"
        const val EXTRA_PROFILE = "profile"
        const val EXTRA_FALLBACKS = "fallbacks"
        private const val CHANNEL_ID = "vpn"
        private const val NOTIF_ID = 1
        const val SOCKS_PORT = 10808
        private const val TAG = "MyVpnService"
    }
}
