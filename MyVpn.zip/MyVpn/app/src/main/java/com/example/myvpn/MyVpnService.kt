package com.example.myvpn

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import org.json.JSONObject
import kotlin.concurrent.thread

class MyVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private var engine: Engine? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopVpn(); stopSelf() }
            else -> {
                val json = intent?.getStringExtra(EXTRA_PROFILE) ?: return START_NOT_STICKY
                val profile = Profile.fromJson(JSONObject(json))
                thread(name = "vpn-start") { startVpn(profile) }
            }
        }
        return START_NOT_STICKY
    }

    private fun startVpn(profile: Profile) {
        try {
            stopVpn()
            VpnState.error.value = null

            val e: Engine = when (profile.type) {
                ProfileType.SSH -> SshEngine()
                ProfileType.V2RAY -> V2RayEngine(this)
            }
            e.start(profile, SOCKS_PORT)
            engine = e

            tun = Builder()
                .setSession(profile.name)
                .addAddress("10.0.0.2", 32)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("1.1.1.1")
                .setMtu(1500)
                // Évite la boucle : le trafic de l'app elle-même (tunnel SSH, V2Ray) sort hors VPN
                .addDisallowedApplication(packageName)
                .establish()

            Tun2Socks.start(tun!!.fd, SOCKS_PORT)
            VpnState.connected.value = profile.id
        } catch (t: Throwable) {
            Log.e(TAG, "Échec de connexion", t)
            VpnState.error.value = t.message ?: t.javaClass.simpleName
            stopVpn()
            stopSelf()
        }
    }

    private fun stopVpn() {
        try { Tun2Socks.stop() } catch (_: Throwable) {}
        engine?.stop(); engine = null
        tun?.close(); tun = null
        VpnState.connected.value = null
    }

    override fun onRevoke() { stopVpn(); super.onRevoke() }
    override fun onDestroy() { stopVpn(); super.onDestroy() }

    companion object {
        const val ACTION_START = "com.example.myvpn.START"
        const val ACTION_STOP = "com.example.myvpn.STOP"
        const val EXTRA_PROFILE = "profile"
        const val SOCKS_PORT = 10808
        private const val TAG = "MyVpnService"
    }
}
