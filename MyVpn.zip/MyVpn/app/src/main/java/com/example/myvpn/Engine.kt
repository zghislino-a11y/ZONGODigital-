package com.example.myvpn

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow

/** Un "moteur" expose un proxy SOCKS5 local (127.0.0.1:socksPort) vers le serveur. */
interface Engine {
    fun start(profile: Profile, socksPort: Int)
    fun stop()
}

/** État partagé service -> interface. */
object VpnState {
    val connected = MutableStateFlow<String?>(null) // id du profil connecté
    val error = MutableStateFlow<String?>(null)
}

/** Pont vers la bibliothèque native tun2socks (TUN -> SOCKS5). À brancher. */
object Tun2Socks {
    fun start(tunFd: Int, socksPort: Int) {
        // TODO : intégrer hev-socks5-tunnel ou tun2socks (AAR/.so) et lui passer
        // le descripteur TUN et 127.0.0.1:socksPort. Sans cela, aucun paquet n'est relayé.
        throw NotImplementedError("tun2socks non intégré : voir README.md")
    }

    fun stop() {
        // TODO
    }
}

/**
 * Moteur V2Ray. À brancher sur libv2ray (Xray/V2Ray-core) :
 *  1. Convertir profile.link (vmess://, vless://...) en JSON de config avec un inbound
 *     SOCKS sur 127.0.0.1:socksPort.
 *  2. Démarrer le cœur avec cette config.
 */
class V2RayEngine(@Suppress("unused") private val context: Context) : Engine {
    override fun start(profile: Profile, socksPort: Int) {
        throw NotImplementedError("libv2ray non intégré : voir README.md")
    }

    override fun stop() {}
}
