package com.example.myvpn

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private var pending: Profile? = null

    private val vpnPermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) pending?.let { startVpn(it) }
    }

    private fun connect(p: Profile) {
        pending = p
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermission.launch(intent) else startVpn(p)
    }

    private fun startVpn(p: Profile) {
        startService(
            Intent(this, MyVpnService::class.java)
                .setAction(MyVpnService.ACTION_START)
                .putExtra(MyVpnService.EXTRA_PROFILE, p.toJson().toString())
        )
    }

    private fun stopVpn() {
        startService(Intent(this, MyVpnService::class.java).setAction(MyVpnService.ACTION_STOP))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = ProfileStore(this)
        setContent { App(store, ::connect, ::stopVpn) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(store: ProfileStore, onConnect: (Profile) -> Unit, onDisconnect: () -> Unit) {
    var profiles by remember { mutableStateOf(store.load()) }
    var showAdd by remember { mutableStateOf(false) }
    val connectedId by VpnState.connected.collectAsState()
    val error by VpnState.error.collectAsState()

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("MyVpn") }) },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) { Text("+") }
            }
        ) { pad ->
            Column(Modifier.padding(pad).padding(16.dp)) {
                error?.let {
                    Text("Erreur : $it", color = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.height(8.dp))
                }
                if (profiles.isEmpty()) Text("Aucun profil. Appuie sur + pour en ajouter un.")
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(profiles, key = { it.id }) { p ->
                        val active = connectedId == p.id
                        Card(Modifier.fillMaxWidth()) {
                            Row(
                                Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        if (p.type == ProfileType.SSH) "SSH · ${p.host}:${p.port}" else "V2Ray",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                                TextButton(onClick = {
                                    profiles = profiles.filter { it.id != p.id }.also(store::save)
                                }) { Text("Suppr.") }
                                Button(onClick = { if (active) onDisconnect() else onConnect(p) }) {
                                    Text(if (active) "Déconnecter" else "Connecter")
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showAdd) {
            AddProfileDialog(
                onDismiss = { showAdd = false },
                onSave = { p ->
                    profiles = (profiles + p).also(store::save)
                    showAdd = false
                }
            )
        }
    }
}

@Composable
fun AddProfileDialog(onDismiss: () -> Unit, onSave: (Profile) -> Unit) {
    var type by remember { mutableStateOf(ProfileType.SSH) }
    var name by remember { mutableStateOf("") }
    var host by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("22") }
    var user by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nouveau profil") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(type == ProfileType.SSH, { type = ProfileType.SSH }, { Text("SSH") })
                    FilterChip(type == ProfileType.V2RAY, { type = ProfileType.V2RAY }, { Text("V2Ray") })
                }
                OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true)
                if (type == ProfileType.SSH) {
                    OutlinedTextField(host, { host = it }, label = { Text("Serveur") }, singleLine = true)
                    OutlinedTextField(port, { port = it }, label = { Text("Port") }, singleLine = true)
                    OutlinedTextField(user, { user = it }, label = { Text("Utilisateur") }, singleLine = true)
                    OutlinedTextField(password, { password = it }, label = { Text("Mot de passe") }, singleLine = true)
                } else {
                    OutlinedTextField(link, { link = it }, label = { Text("Lien vmess:// vless:// …") })
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = {
                    onSave(
                        Profile(
                            name = name.trim(), type = type,
                            host = host.trim(), port = port.toIntOrNull() ?: 22,
                            user = user.trim(), password = password, link = link.trim()
                        )
                    )
                }
            ) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}
