# MyVpn — squelette Android (SSH + V2Ray)

## Ouvrir le projet
1. Android Studio (Koala ou plus récent) → **Open** → dossier `MyVpn`.
2. Laisser Gradle synchroniser (il génère le wrapper), puis lancer sur un téléphone réel (le VPN marche mal sur émulateur).

## Ce qui est déjà fait
- Écran Compose : liste de profils, ajout / suppression, bouton Connecter / Déconnecter.
- `MyVpnService` : demande de permission VPN, interface TUN, gestion du cycle de vie.
- `SshEngine` : tunnel SSH avec serveur SOCKS5 local (équivalent de `ssh -D`), via sshj.

## Ce qu'il reste à brancher (deux pièces natives)
1. **tun2socks** (`Tun2Socks` dans `Engine.kt`) : convertit les paquets du TUN en connexions SOCKS5 vers `127.0.0.1:10808`. Options courantes : `hev-socks5-tunnel` ou `tun2socks`. Sans cela, la connexion échoue avec un message d'erreur explicite.
2. **libv2ray** (`V2RayEngine` dans `Engine.kt`) : cœur Xray/V2Ray en AAR (voir le projet open source v2rayNG pour un exemple d'intégration). Il faut :
   - convertir le lien `vmess://` / `vless://` en JSON de config avec un inbound SOCKS sur `127.0.0.1:10808` ;
   - démarrer le cœur avec cette config.

## Points d'attention
- **DNS** : SSH ne transporte pas l'UDP. Pour le profil SSH, il faut un DNS passant en TCP (option du tun2socks ou résolveur local).
- **Sécurité** : l'empreinte de clé hôte SSH n'est pas vérifiée si le champ est vide ; les mots de passe sont stockés en clair (passer à `EncryptedSharedPreferences` et à l'authentification par clé).
- **Boucle** : l'app s'exclut elle-même du VPN (`addDisallowedApplication`) pour que le tunnel SSH / V2Ray ne repasse pas par le TUN.
- Ajouter ensuite : notification de service au premier plan, reconnexion automatique, import par QR code, test de latence.
